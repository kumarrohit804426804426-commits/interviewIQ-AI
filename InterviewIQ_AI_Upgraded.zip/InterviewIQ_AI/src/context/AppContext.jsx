import { createContext, useCallback, useContext, useEffect, useMemo, useState } from 'react';
import { storageService } from '../services/storageService';

const AppContext = createContext(null);
export function AppProvider({ children }) {
  const [ready, setReady] = useState(false);
  const [profile, setProfile] = useState({ name: 'Learner', email: '', education: '', skills: [], interests: [], goal: '' });
  const [preferences, setPreferences] = useState({ notifications: true, weeklySummary: true });
  const [subscription, setSubscription] = useState({ plan: 'Free', status: 'active' });
  const [role, setRole] = useState('student');
  const [toast, setToast] = useState(null);
  const [revision, setRevision] = useState(0);
  const refresh = useCallback(() => setRevision(value => value + 1), []);

  useEffect(() => {
    let alive = true;
    storageService.seed().then(() => {
      if (!alive) return;
      setProfile(storageService.getSetting('profile', {}));
      setPreferences(storageService.getSetting('preferences', {}));
      setSubscription(storageService.getSetting('subscription', { plan: 'Free', status: 'active' }));
      setRole(storageService.getSetting('demoRole', 'student'));
      setReady(true);
    }).catch(error => {
      console.error(error);
      if (alive) { setToast({ message: 'Browser storage could not be initialized. Check private browsing settings.', type: 'error' }); setReady(true); }
    });
    return () => { alive = false; };
  }, []);

  const notify = useCallback((message, type = 'success') => {
    setToast({ message, type });
    window.clearTimeout(notify.timer);
    notify.timer = window.setTimeout(() => setToast(null), 3600);
  }, []);
  const updateProfile = useCallback(next => {
    const value = { ...profile, ...next };
    setProfile(value); storageService.setSetting('profile', value); refresh();
  }, [profile, refresh]);
  const updatePreferences = useCallback(next => {
    const value = { ...preferences, ...next };
    setPreferences(value); storageService.setSetting('preferences', value);
  }, [preferences]);
  const updateSubscription = useCallback(next => {
    const value = { ...subscription, ...next };
    setSubscription(value); storageService.setSetting('subscription', value);
  }, [subscription]);
  const updateRole = useCallback(next => { setRole(next); storageService.setSetting('demoRole', next); }, []);
  const logActivity = useCallback(async (item) => {
    await storageService.put('activity', { ...item, createdAt: item.createdAt || new Date().toISOString() });
    refresh();
  }, [refresh]);

  const value = useMemo(() => ({ ready, profile, preferences, subscription, role, toast, setToast, notify, updateProfile, updatePreferences, updateSubscription, updateRole, logActivity, refresh, revision }), [ready, profile, preferences, subscription, role, toast, notify, updateProfile, updatePreferences, updateSubscription, updateRole, logActivity, refresh, revision]);
  return <AppContext.Provider value={value}>{children}</AppContext.Provider>;
}
export function useApp() {
  const context = useContext(AppContext);
  if (!context) throw new Error('useApp must be used inside AppProvider.');
  return context;
}
