import { Navigate, Route, Routes } from 'react-router-dom';
import { useApp } from './context/AppContext';
import Layout from './components/Layout';
import { Loading } from './components/UI';
import Dashboard from './pages/Dashboard';
import Interview from './pages/Interview';
import Gate from './pages/Gate';
import Learning from './pages/Learning';
import Coding from './pages/Coding';
import Aptitude from './pages/Aptitude';
import Resume from './pages/Resume';
import Performance from './pages/Performance';
import Saved from './pages/Saved';
import History from './pages/History';
import Profile from './pages/Profile';
import Pro from './pages/Pro';
import Settings from './pages/Settings';
import Admin from './pages/Admin';

export default function App() {
  const { ready } = useApp();
  if (!ready) return <div className="app-loading"><Loading label="Preparing your workspace…"/></div>;
  return <Routes><Route element={<Layout/>}>
    <Route path="/" element={<Dashboard/>}/>
    <Route path="/interview" element={<Interview/>}/>
    <Route path="/gate" element={<Gate/>}/>
    <Route path="/learning" element={<Learning/>}/>
    <Route path="/coding" element={<Coding/>}/>
    <Route path="/aptitude" element={<Aptitude/>}/>
    <Route path="/resume" element={<Resume/>}/>
    <Route path="/performance" element={<Performance/>}/>
    <Route path="/saved" element={<Saved/>}/>
    <Route path="/history" element={<History/>}/>
    <Route path="/profile" element={<Profile/>}/>
    <Route path="/pro" element={<Pro/>}/>
    <Route path="/settings" element={<Settings/>}/>
    <Route path="/admin" element={<Admin/>}/>
    <Route path="*" element={<Navigate to="/" replace/>}/>
  </Route></Routes>;
}
