import { useRef, useState } from 'react';
import { FileText, FileUp, ShieldCheck, Sparkles, Upload, X } from 'lucide-react';
import { getDocument, GlobalWorkerOptions } from 'pdfjs-dist';
import pdfWorker from 'pdfjs-dist/build/pdf.worker.min.mjs?url';
import { useApp } from '../context/AppContext';
import { geminiService } from '../services/geminiService';
import { storageService } from '../services/storageService';
import { Badge, Button, Field, Loading, PageHeader, Panel, ProgressBar } from '../components/UI';

GlobalWorkerOptions.workerSrc = pdfWorker;

async function extractPdfText(file) {
  const buffer = await file.arrayBuffer();
  const pdf = await getDocument({ data: buffer }).promise;
  const pages = [];
  for (let pageNo = 1; pageNo <= pdf.numPages; pageNo += 1) {
    const page = await pdf.getPage(pageNo);
    const content = await page.getTextContent();
    pages.push(content.items.map(item => item.str).join(' '));
  }
  return pages.join('\n').trim();
}

export default function Resume() {
  const { notify, logActivity } = useApp();
  const inputRef = useRef(null);
  const [file, setFile] = useState(null);
  const [text, setText] = useState('');
  const [role, setRole] = useState('Software Developer');
  const [extracting, setExtracting] = useState(false);
  const [loading, setLoading] = useState(false);
  const [analysis, setAnalysis] = useState(null);
  const [resumeId, setResumeId] = useState(null);

  async function handleFile(selected) {
    if (!selected) return;
    if (selected.size > 8 * 1024 * 1024) return notify('Please upload a file smaller than 8 MB.', 'error');
    setFile(selected); setAnalysis(null); setExtracting(true);
    try {
      if (selected.type === 'application/pdf' || selected.name.toLowerCase().endsWith('.pdf')) setText(await extractPdfText(selected));
      else if (selected.type.startsWith('text/') || selected.name.toLowerCase().endsWith('.txt')) setText(await selected.text());
      else throw new Error('Upload a PDF or plain-text (.txt) resume.');
      notify('Resume text extracted successfully.');
    } catch (error) { setText(''); setFile(null); notify(error.message || 'Unable to read this file.', 'error'); }
    finally { setExtracting(false); }
  }
  async function analyze() {
    if (text.trim().length < 100) return notify('The extracted resume text is too short. Upload a text-based PDF or paste more content.', 'error');
    setLoading(true);
    try {
      const result = await geminiService.analyzeResume({ text, role });
      const record = await storageService.put('resumes', { filename: file?.name || 'Pasted resume', role, text: text.slice(0, 22000), analysis: result, createdAt: new Date().toISOString() });
      setResumeId(record.id); setAnalysis(result);
      await logActivity({ type: 'resume', label: `Analyzed resume for ${role}`, score: result.score });
      notify('Resume analysis completed and saved locally.');
    } catch (error) { notify(error.message, 'error'); }
    finally { setLoading(false); }
  }
  function clearFile() { setFile(null); setText(''); setAnalysis(null); setResumeId(null); if (inputRef.current) inputRef.current.value = ''; }

  return <>
    <PageHeader eyebrow="CAREER TOOLS" title="Resume Analyzer" description="Review resume content, identify missing keywords and get practical improvements for your target role." action={<Badge tone="blue"><Sparkles size={12}/> Gemini powered</Badge>}/>
    <div className="resume-layout"><div className="resume-input-column"><Panel className="resume-upload-panel"><div className="panel-kicker"><FileUp size={16}/> RESUME INPUT</div><h2>Start with your resume.</h2><p>Upload a text-based PDF or paste resume content for AI analysis.</p>{!file ? <button className="upload-zone" onClick={() => inputRef.current?.click()} onDragOver={e => e.preventDefault()} onDrop={e => { e.preventDefault(); handleFile(e.dataTransfer.files?.[0]); }}><div className="upload-icon"><Upload size={22}/></div><strong>Drop your resume here</strong><span>or browse files · PDF or TXT · up to 8 MB</span><input ref={inputRef} type="file" accept=".pdf,.txt,application/pdf,text/plain" hidden onChange={e => handleFile(e.target.files?.[0])}/></button> : <div className="file-selected"><div className="file-type-icon"><FileText size={22}/></div><div><b>{file.name}</b><small>{(file.size / 1024).toFixed(0)} KB · {text.length.toLocaleString()} characters extracted</small></div><button onClick={clearFile} aria-label="Remove file"><X size={16}/></button></div>}{extracting && <Loading label="Extracting resume text…"/>}<Field label="Target role"><input value={role} onChange={e => setRole(e.target.value)} placeholder="e.g. Data Analyst"/></Field><Field label="Extracted / pasted resume text"><textarea rows={12} value={text} onChange={e => setText(e.target.value)} placeholder="Your resume text will appear here after upload. You can also paste your resume content directly."/></Field><div className="resume-input-footer"><span>{text.length.toLocaleString()} characters</span><Button onClick={analyze} disabled={loading || extracting || text.trim().length < 100}>{loading ? 'Analyzing…' : 'Analyze my resume'} <Sparkles size={15}/></Button></div></Panel><div className="resume-privacy"><ShieldCheck size={17}/><span><b>Local-first privacy</b><small>Resume text and analysis are stored in this browser. The text is sent to Gemini only when you choose Analyze.</small></span></div></div>
      <div className="resume-results-column">{analysis ? <><Panel className="resume-score-panel"><div className="eyebrow">AI RESUME ESTIMATE</div><div className="resume-score-row"><div><strong>{analysis.score}</strong><small>/100</small></div><div><Badge tone={analysis.score >= 80 ? 'green' : analysis.score >= 60 ? 'blue' : 'orange'}>{analysis.roleFit || 'Role fit reviewed'}</Badge><p>{analysis.summary}</p></div></div><ProgressBar value={analysis.score}/><div className="resume-score-disclaimer">This is an AI-generated estimate for guidance only, not a verified ATS score or hiring prediction.</div></Panel><Panel><h3>Resume strengths</h3>{analysis.strengths.map((item, i) => <div className="feedback-item positive" key={i}><ShieldCheck size={15}/>{item}</div>)}</Panel><Panel><h3>Keywords to consider</h3><div className="keyword-cloud">{analysis.missingKeywords.map((item, i) => <Badge key={i} tone="orange">{item}</Badge>)}</div></Panel><Panel><h3>Recommended improvements</h3><div className="resume-suggestion-groups"><div><b>Skills to highlight</b>{analysis.skillRecommendations.map((item, i) => <p key={i}>· {item}</p>)}</div><div><b>Formatting and structure</b>{analysis.formattingSuggestions.map((item, i) => <p key={i}>· {item}</p>)}</div><div><b>Experience highlights</b>{analysis.experienceHighlights.map((item, i) => <p key={i}>· {item}</p>)}</div></div></Panel><Button variant="secondary" onClick={clearFile}>Analyze another resume</Button></> : <Panel className="resume-empty"><div className="resume-empty-icon"><FileText size={26}/></div><h3>Your analysis will appear here.</h3><p>Upload a resume, confirm the extracted text, and select your target role to receive a structured review.</p><div className="resume-preview-list"><div><span>01</span><b>Resume strengths</b></div><div><span>02</span><b>Missing role keywords</b></div><div><span>03</span><b>Skills and formatting recommendations</b></div><div><span>04</span><b>AI-generated compatibility estimate</b></div></div></Panel>}</div></div>
  </>;
}
