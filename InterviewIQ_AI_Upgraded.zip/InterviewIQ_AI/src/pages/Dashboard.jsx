import { useEffect, useMemo, useState } from 'react';
import { Link } from 'react-router-dom';
import { Area, AreaChart, CartesianGrid, ResponsiveContainer, Tooltip, XAxis, YAxis } from 'recharts';
import { Activity, ArrowUpRight, BookOpen, BrainCircuit, CheckCircle2, Code2, FileText, Flame, MessageSquareText, Sparkles, Target, Zap } from 'lucide-react';
import { useApp } from '../context/AppContext';
import { storageService } from '../services/storageService';
import { geminiService } from '../services/geminiService';
import { recommendedQuestions } from '../data/content';
import { Badge, Button, EmptyState, PageHeader, Panel, ProgressBar, SectionTitle, StatCard } from '../components/UI';

function buildWeek(activities) {
  return Array.from({ length: 7 }, (_, index) => {
    const date = new Date(); date.setDate(date.getDate() - (6 - index)); date.setHours(0, 0, 0, 0);
    const next = new Date(date); next.setDate(next.getDate() + 1);
    const count = activities.filter(item => { const d = new Date(item.createdAt); return d >= date && d < next; }).length;
    return { day: date.toLocaleDateString('en-US', { weekday: 'short' }), sessions: count };
  });
}

export default function Dashboard() {
  const { profile, revision, notify, logActivity } = useApp();
  const [activity, setActivity] = useState([]);
  const [sessions, setSessions] = useState([]);
  const [quizzes, setQuizzes] = useState([]);
  const [saved, setSaved] = useState([]);
  const [recommendations, setRecommendations] = useState(null);
  const [loadingAI, setLoadingAI] = useState(false);

  useEffect(() => {
    Promise.all(['activity', 'sessions', 'quizzes', 'saved'].map(store => storageService.getAll(store))).then(([a, s, q, b]) => {
      setActivity(a); setSessions(s); setQuizzes(q); setSaved(b);
    });
  }, [revision]);

  const average = quizzes.length ? Math.round(quizzes.reduce((sum, quiz) => sum + (quiz.percentage || quiz.score || 0), 0) / quizzes.length) : 0;
  const week = useMemo(() => buildWeek(activity), [activity]);
  const lessons = activity.filter(item => item.type === 'lesson').length;
  const interviewCount = sessions.length;
  const questionsAttempted = sessions.reduce((sum, item) => sum + (item.questions?.length || 0), 0) + quizzes.reduce((sum, item) => sum + (item.total || 0), 0);
  const latestSessions = [...sessions].slice(0, 3);
  const greeting = new Date().getHours() < 12 ? 'Good morning' : new Date().getHours() < 18 ? 'Good afternoon' : 'Good evening';
  const dateLabel = new Date().toLocaleDateString('en-US', { weekday: 'long', month: 'long', day: 'numeric', year: 'numeric' }).toUpperCase();

  async function saveQuestion(question) {
    if (saved.some(item => item.question === question)) return notify('This question is already saved.', 'info');
    const item = await storageService.put('saved', { type: 'Interview question', question, category: 'Recommended practice' });
    setSaved(current => [...current, item]);
    notify('Question added to Saved Questions.');
  }
  async function getRecommendations() {
    setLoadingAI(true);
    try { setRecommendations(await geminiService.generateLearningRecommendations({ profile, activity })); }
    catch (error) { notify(error.message, 'error'); }
    finally { setLoadingAI(false); }
  }

  return <>
    <PageHeader eyebrow={dateLabel} title={`${greeting}, ${profile.name?.split(' ')[0] || 'there'}.`} description="A little focused practice today moves your career forward." action={<Link className="btn primary" to="/interview"><Sparkles size={16} /> Start a mock interview</Link>} />
    <div className="welcome-strip"><div className="welcome-copy"><div className="welcome-kicker"><span className="live-dot" /> YOUR DAILY PREPARATION</div><h2>Build confidence, one session at a time.</h2><p>Pick up where you left off or choose a focused activity for today.</p><div className="welcome-actions"><Link to="/coding" className="btn white"><Code2 size={16} /> Solve a problem</Link><Link to="/aptitude" className="btn ghost-white">Practice aptitude <ArrowUpRight size={15} /></Link></div></div><div className="welcome-art"><div className="orbit orbit-one"/><div className="orbit orbit-two"/><div className="orbit-center"><Target size={34}/></div><div className="orbit-chip chip-one"><Zap size={15}/></div><div className="orbit-chip chip-two"><BrainCircuit size={15}/></div><div className="orbit-chip chip-three"><CheckCircle2 size={15}/></div></div></div>

    <div className="stats-grid four">
      <StatCard label="Questions attempted" value={questionsAttempted} change="Across interviews and quizzes" icon={Activity} tone="blue" />
      <StatCard label="Mock interviews" value={interviewCount} change="Saved interview reports" icon={MessageSquareText} tone="violet" />
      <StatCard label="Average quiz score" value={`${average}%`} change={quizzes.length ? `${quizzes.length} completed quizzes` : 'No quizzes completed yet'} icon={Target} tone="green" />
      <StatCard label="Lessons completed" value={lessons} change="Keep your learning streak" icon={BookOpen} tone="orange" />
    </div>

    <div className="dashboard-grid">
      <Panel className="chart-panel"><SectionTitle title="Your activity" description="Practice sessions over the last 7 days" action={<Badge tone="blue">This week</Badge>} /><div className="chart-area"><ResponsiveContainer width="100%" height="100%"><AreaChart data={week} margin={{ top: 12, right: 8, left: -24, bottom: 0 }}><defs><linearGradient id="activityFill" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stopColor="#1684ff" stopOpacity={0.20}/><stop offset="100%" stopColor="#1684ff" stopOpacity={0.01}/></linearGradient></defs><CartesianGrid strokeDasharray="3 5" vertical={false} stroke="#edf0f4"/><XAxis dataKey="day" axisLine={false} tickLine={false} tick={{ fill: '#9699a1', fontSize: 12 }}/><YAxis allowDecimals={false} axisLine={false} tickLine={false} tick={{ fill: '#9699a1', fontSize: 12 }}/><Tooltip contentStyle={{ border: '1px solid #edf0f4', borderRadius: 12, boxShadow: '0 10px 25px rgba(30,40,60,.08)' }}/><Area type="monotone" dataKey="sessions" stroke="#1684ff" strokeWidth={2.5} fill="url(#activityFill)"/></AreaChart></ResponsiveContainer></div><div className="chart-foot"><span><span className="legend-dot"/> Learning and practice activity</span><strong>{week.reduce((sum, day) => sum + day.sessions, 0)} sessions this week</strong></div></Panel>
      <Panel className="progress-panel"><SectionTitle title="Preparation pulse" description="A snapshot of your learning habits"/><div className="pulse-score"><div><strong>{Math.min(100, activity.length * 8 + 16)}<small>/100</small></strong><span>Learning momentum</span></div><div className="pulse-ring"><div className="pulse-inner"><Flame size={22}/></div></div></div><div className="mini-progress-list"><div><div className="mini-progress-label"><span>Interview practice</span><strong>{Math.min(100, interviewCount * 16)}%</strong></div><ProgressBar value={Math.min(100, interviewCount * 16)}/></div><div><div className="mini-progress-label"><span>Learning consistency</span><strong>{Math.min(100, lessons * 12)}%</strong></div><ProgressBar value={Math.min(100, lessons * 12)} color="purple"/></div><div><div className="mini-progress-label"><span>Quiz practice</span><strong>{Math.min(100, quizzes.length * 20)}%</strong></div><ProgressBar value={Math.min(100, quizzes.length * 20)} color="green"/></div></div></Panel>
    </div>

    <div className="section-block"><SectionTitle title="Continue preparing" description="Jump into a focused learning session"/><div className="quick-grid">
      <Link to="/interview" className="quick-card"><div className="quick-icon blue-bg"><MessageSquareText size={20}/></div><div><strong>AI Mock Interview</strong><p>Practice realistic questions with AI feedback</p><span>Start practice <ArrowUpRight size={14}/></span></div></Link>
      <Link to="/learning" className="quick-card"><div className="quick-icon purple-bg"><BookOpen size={20}/></div><div><strong>Programming paths</strong><p>Structured lessons in five languages</p><span>Continue learning <ArrowUpRight size={14}/></span></div></Link>
      <Link to="/gate" className="quick-card"><div className="quick-icon green-bg"><GraduationCapIcon/></div><div><strong>GATE preparation</strong><p>Subject-wise practice and revision</p><span>Explore subjects <ArrowUpRight size={14}/></span></div></Link>
      <Link to="/resume" className="quick-card"><div className="quick-icon orange-bg"><FileText size={20}/></div><div><strong>Resume Analyzer</strong><p>Get actionable feedback on your resume</p><span>Analyze resume <ArrowUpRight size={14}/></span></div></Link>
    </div></div>

    <div className="dashboard-pro-card"><div className="dashboard-pro-mark"><Sparkles size={20}/></div><div className="dashboard-pro-copy"><span>INTERVIEWIQ PRO</span><strong>Go deeper with your preparation.</strong><small>Extended mock interviews, richer AI feedback and more detailed progress insights.</small></div><Link to="/pro" className="btn secondary">Explore PRO <ArrowUpRight size={15}/></Link></div>

    <div className="dashboard-grid lower-grid"><Panel><SectionTitle title="Recommended questions" description="A few prompts worth practising" action={<Link className="text-link" to="/saved">Saved list <ArrowUpRight size={14}/></Link>}/><div className="recommend-list">{recommendedQuestions.slice(0, 3).map((question, i) => <div className="recommend-row" key={question}><span className="question-number">0{i + 1}</span><p>{question}</p><button className="icon-btn" onClick={() => saveQuestion(question)} aria-label="Save question"><BookmarkIcon/></button></div>)}</div></Panel><Panel><SectionTitle title="Recent activity" description="Your latest learning moments"/><div className="recent-list">{activity.slice(0, 4).map(item => <div className="recent-row" key={item.id}><div className={`recent-icon ${item.type}`}><Activity size={16}/></div><div><strong>{item.label}</strong><small>{new Date(item.createdAt).toLocaleDateString(undefined, { month: 'short', day: 'numeric' })}</small></div><span className="recent-tag">{item.type}</span></div>)}{!activity.length && <EmptyState title="Your activity will show here" description="Complete a lesson or practice session to get started."/>}</div></Panel></div>
    <Panel className="recent-sessions-panel"><SectionTitle title="Recent interview sessions" description="Pick up where your last mock interview left off" action={<Link className="text-link" to="/history">View history <ArrowUpRight size={14}/></Link>}/>{latestSessions.length ? <div className="recent-session-list">{latestSessions.map(session => <div className="recent-session-row" key={session.id}><div className="recent-icon interview"><MessageSquareText size={16}/></div><div><strong>{session.role || 'Mock interview'} · {session.type}</strong><small>{new Date(session.createdAt).toLocaleDateString(undefined, { month: 'short', day: 'numeric' })} · {session.questions?.length || 0} questions</small></div><Badge tone={(session.score || 0) >= 80 ? 'green' : 'blue'}>{session.score ?? '—'}/100</Badge></div>)}</div> : <EmptyState title="No interview sessions yet" description="Complete an AI mock interview and your report will appear here."/>}</Panel>

    <Panel className="ai-recommend-card"><div><div className="ai-label"><Sparkles size={15}/> GEMINI LEARNING ASSISTANT</div><h2>Need a clear next step?</h2><p>Generate a short, personalized learning plan from your recent activity and goals.</p></div><div className="ai-recommend-action"><Button onClick={getRecommendations} disabled={loadingAI}>{loadingAI ? 'Creating plan…' : 'Generate my plan'} <Sparkles size={15}/></Button></div>{recommendations && <div className="ai-plan"><strong>{recommendations.summary}</strong><div className="ai-plan-items">{recommendations.recommendations.slice(0, 3).map((item, i) => <div key={`${item.title}-${i}`}><span>{i + 1}</span><div><b>{item.title}</b><small>{item.reason} · {item.minutesPerDay || 30} min/day</small></div></div>)}</div></div>}</Panel>
  </>;
}

function BookmarkIcon() { return <BookOpen size={16}/>; }
function GraduationCapIcon() { return <BookOpen size={20}/>; }
