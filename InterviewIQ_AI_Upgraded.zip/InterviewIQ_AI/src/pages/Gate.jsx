import { useEffect, useMemo, useState } from 'react';
import { ArrowRight, Bookmark, CheckCircle2, ChevronRight, GraduationCap, RotateCcw } from 'lucide-react';
import { gateQuestions, gateSubjects } from '../data/content';
import { useApp } from '../context/AppContext';
import { storageService } from '../services/storageService';
import { Badge, Button, EmptyState, PageHeader, Panel, ProgressBar } from '../components/UI';

export default function Gate() {
  const { notify, logActivity } = useApp();
  const [subject, setSubject] = useState('programming');
  const [questionIndex, setQuestionIndex] = useState(0);
  const [answers, setAnswers] = useState({});
  const [submitted, setSubmitted] = useState(false);
  const [showAll, setShowAll] = useState(false);
  const [customQuestions, setCustomQuestions] = useState([]);
  const [yearFilter, setYearFilter] = useState('All sets');
  useEffect(() => { storageService.getAll('adminContent').then(rows => setCustomQuestions(rows.filter(row => row.type === 'gateQuestion'))); }, []);
  const currentSubject = gateSubjects.find(item => item.id === subject);
  const yearOptions = useMemo(() => ['All sets', 'Practice / unverified', ...[...new Set(customQuestions.map(item => item.year).filter(Boolean))].sort((a, b) => b - a).map(String)], [customQuestions]);
  const questions = useMemo(() => [...gateQuestions, ...customQuestions].filter(question => (question.subject === subject || showAll) && (yearFilter === 'All sets' || (yearFilter === 'Practice / unverified' ? !question.year : String(question.year) === yearFilter))), [subject, showAll, customQuestions, yearFilter]);
  const current = questions[questionIndex];
  const selected = current ? answers[current.id] : undefined;
  const complete = questions.length > 0 && questionIndex === questions.length - 1;
  const score = questions.filter(question => answers[question.id] === question.answer).length;

  function chooseSubject(id) { setSubject(id); setQuestionIndex(0); setAnswers({}); setSubmitted(false); setShowAll(false); setYearFilter('All sets'); }
  async function finish() {
    setSubmitted(true);
    const percentage = Math.round(score / questions.length * 100);
    await storageService.put('quizzes', { type: 'GATE Practice', subject: currentSubject?.name || 'All subjects', score, total: questions.length, percentage, answers: questions.map(q => ({ questionId: q.id, selected: answers[q.id], correct: q.answer })), createdAt: new Date().toISOString() });
    for (const topic of [...new Set(questions.map(item => item.topic).filter(Boolean))]) await storageService.put('progress', { id: `gate:${subject}:${topic}`, language: 'GATE', title: `${topic} practice`, category: 'GATE topic', completed: true });
    await logActivity({ type: 'quiz', label: `Completed GATE practice · ${currentSubject?.name || 'All subjects'}`, score: percentage });
    notify('Your GATE practice result has been saved.');
  }
  async function bookmark(question) {
    const items = await storageService.getAll('saved');
    if (items.some(item => item.questionId === question.id)) return notify('This question is already saved.', 'info');
    await storageService.put('saved', { type: 'GATE question', questionId: question.id, question: question.question, category: currentSubject?.name || 'GATE', options: question.options, explanation: question.explanation });
    notify('Question saved.');
  }

  return <>
    <PageHeader eyebrow="EXAM PREPARATION" title="GATE Preparation" description="Revise core computer science subjects with focused topic practice and year-organized local question sets." action={<Badge tone="green">Local question bank</Badge>}/>
    <div className="gate-layout"><aside className="subject-list"><div className="subject-list-head"><GraduationCap size={18}/><strong>Subjects</strong><span>{gateSubjects.length}</span></div>{gateSubjects.map(item => <button key={item.id} className={`subject-button ${subject === item.id && !showAll ? 'selected' : ''}`} onClick={() => chooseSubject(item.id)}><div className="subject-code">{item.code}</div><div><b>{item.name}</b><small>{item.topics.length} topics</small></div><ChevronRight size={15}/></button>)}<button className={`subject-button all-subjects ${showAll ? 'selected' : ''}`} onClick={() => { setShowAll(true); setQuestionIndex(0); setAnswers({}); setSubmitted(false); }}><div className="subject-code">ALL</div><div><b>All available questions</b><small>Mixed revision</small></div><ChevronRight size={15}/></button></aside>
      <div className="gate-main"><div className="gate-filter-toolbar"><span>Question set</span><select value={yearFilter} onChange={event => { setYearFilter(event.target.value); setQuestionIndex(0); setAnswers({}); setSubmitted(false); }}><option>All sets</option>{yearOptions.filter(item => item !== 'All sets').map(item => <option key={item}>{item}</option>)}</select><small>Only year-tagged items are grouped as previous-year questions. Other items remain marked as practice.</small></div><Panel className="subject-overview"><div><div className="eyebrow">{showAll ? 'MIXED REVISION' : `${currentSubject?.code || 'GATE'} · SUBJECT OVERVIEW`}</div><h2>{showAll ? 'All available questions' : currentSubject?.name}</h2><p>{showAll ? 'Try a mixed set from all currently available subjects.' : 'Select a topic, revise the concept, and reinforce it with practice questions.'}</p></div><div className="subject-progress"><strong>{questions.length}</strong><small>practice questions</small></div></Panel>
      {!showAll && <div className="topic-pills">{currentSubject?.topics.map((topic, i) => <button key={topic} className="topic-pill" onClick={() => { const idx = questions.findIndex(q => q.topic === topic); if (idx >= 0) { setQuestionIndex(idx); setSubmitted(false); } else notify('More questions for this topic can be added to the local dataset.', 'info'); }}><span>{String(i + 1).padStart(2, '0')}</span>{topic}<ChevronRight size={13}/></button>)}</div>}
      {current && !submitted && <Panel className="quiz-panel"><div className="quiz-topline"><span>QUESTION {questionIndex + 1} OF {questions.length}</span><Badge tone="blue">{current.topic}</Badge></div><ProgressBar value={(questionIndex + 1) / questions.length * 100}/><h3>{current.question}</h3><div className="options-list">{current.options.map((option, i) => <button key={option} className={`option-button ${selected === i ? 'selected' : ''}`} onClick={() => setAnswers({ ...answers, [current.id]: i })}><span className="option-key">{String.fromCharCode(65 + i)}</span><span>{option}</span>{selected === i && <CheckCircle2 size={17}/>}</button>)}</div><div className="quiz-footer"><button className="save-question" onClick={() => bookmark(current)}><Bookmark size={15}/> Save question</button><div><Button variant="secondary" onClick={() => setQuestionIndex(Math.max(0, questionIndex - 1))} disabled={questionIndex === 0}>Previous</Button>{complete ? <Button onClick={finish} disabled={Object.keys(answers).length !== questions.length}>Submit practice <CheckCircle2 size={15}/></Button> : <Button onClick={() => setQuestionIndex(questionIndex + 1)} disabled={selected === undefined}>Next question <ArrowRight size={15}/></Button>}</div></div></Panel>}
      {!current && <EmptyState title="No questions in this set yet" description="The local question bank can be expanded with additional topic datasets."/>}
      {submitted && <Panel className="result-panel"><div className="result-score"><strong>{score}/{questions.length}</strong><span>{Math.round(score / questions.length * 100)}% score</span></div><div><Badge tone={score / questions.length >= .7 ? 'green' : 'orange'}>{score / questions.length >= .7 ? 'Good work' : 'Keep revising'}</Badge><h3>{score === questions.length ? 'Perfect practice round.' : 'Your result is ready.'}</h3><p>Review the explanations below and try another practice round to reinforce the concepts.</p></div><Button onClick={() => { setAnswers({}); setQuestionIndex(0); setSubmitted(false); }}><RotateCcw size={15}/> Practise again</Button></Panel>}
      {submitted && questions.map((question, i) => <Panel className="answer-review" key={question.id}><div className="review-question"><span>{String(i + 1).padStart(2, '0')}</span><b>{question.question}</b><Badge tone={answers[question.id] === question.answer ? 'green' : 'red'}>{answers[question.id] === question.answer ? 'Correct' : 'Review'}</Badge></div><div className="review-explanation"><b>Correct answer: {question.options[question.answer]}</b><p>{question.explanation}</p></div></Panel>)}
      </div></div>
  </>;
}
