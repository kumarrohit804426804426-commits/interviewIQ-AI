import { useEffect, useState } from 'react';
import { ArrowRight, BookOpen, Check, CheckCircle2, Clock3, Code2, Sparkles } from 'lucide-react';
import { programmingPaths } from '../data/content';
import { useApp } from '../context/AppContext';
import { storageService } from '../services/storageService';
import { Badge, Button, PageHeader, Panel, ProgressBar } from '../components/UI';

export default function Learning() {
  const { notify, logActivity, revision } = useApp();
  const [language, setLanguage] = useState('JavaScript');
  const [lessonIndex, setLessonIndex] = useState(0);
  const [completed, setCompleted] = useState({});
  const [customLessons, setCustomLessons] = useState([]);
  const path = programmingPaths.find(item => item.language === language);
  const lessons = [
    ...path.lessons.map(item => ({ key: `${language}:${item[0]}`, title: item[0], description: item[1], code: item[2] })),
    ...customLessons.filter(item => item.language === language).map(item => ({ key: `custom:${item.id}`, title: item.title, description: item.description, code: item.code, custom: true })),
  ];
  const lesson = lessons[lessonIndex] || lessons[0];

  useEffect(() => {
    Promise.all([storageService.getAll('progress'), storageService.getAll('adminContent')]).then(([rows, content]) => {
      setCompleted(Object.fromEntries(rows.map(row => [row.id, true])));
      setCustomLessons(content.filter(row => row.type === 'customLesson'));
    });
  }, [revision]);

  async function markComplete() {
    await storageService.put('progress', { id: lesson.key, language, title: lesson.title, category: 'Programming lesson', completed: true, createdAt: new Date().toISOString() });
    await logActivity({ type: 'lesson', label: `Completed ${language}: ${lesson.title}` });
    setCompleted(current => ({ ...current, [lesson.key]: true }));
    notify('Lesson marked as complete.');
  }

  const doneCount = lessons.filter(item => completed[item.key]).length;

  return <>
    <PageHeader eyebrow="LEARNING PATHS" title="Programming Learning" description="Build your fundamentals with structured, topic-wise lessons and concise code examples." action={<Badge tone="blue">5 learning paths</Badge>}/>
    <div className="language-tabs">{programmingPaths.map(item => <button key={item.language} className={`language-tab ${language === item.language ? 'active' : ''}`} onClick={() => { setLanguage(item.language); setLessonIndex(0); }}><Code2 size={16}/>{item.language}</button>)}</div>
    <div className="learning-layout">
      <Panel className="lesson-sidebar">
        <div className="path-title"><div className="language-symbol">{language.slice(0, 1)}</div><div><div className="eyebrow">LEARNING PATH</div><h3>{path.tone}</h3></div></div>
        <div className="path-progress"><div><span>Path progress</span><strong>{doneCount}/{lessons.length}</strong></div><ProgressBar value={lessons.length ? doneCount / lessons.length * 100 : 0}/></div>
        <div className="lesson-list">{lessons.map((item, index) => <button key={item.key} className={`lesson-list-item ${index === lessonIndex ? 'active' : ''}`} onClick={() => setLessonIndex(index)}><span className={`lesson-check ${completed[item.key] ? 'done' : ''}`}>{completed[item.key] ? <Check size={13}/> : String(index + 1).padStart(2, '0')}</span><span><b>{item.title}</b><small><Clock3 size={11}/> {item.custom ? 'Custom lesson' : '15–20 min'}</small></span></button>)}</div>
        <div className="path-note"><Sparkles size={15}/><span>Complete each lesson to build a consistent learning record.</span></div>
      </Panel>
      <div className="lesson-content">
        <Panel className="lesson-hero">
          <div className="lesson-meta"><Badge tone="blue">{language}</Badge><span>LESSON {lessonIndex + 1} / {lessons.length}</span></div>
          <h2>{lesson.title}</h2><p>{lesson.description}</p>
          <div className="lesson-code-label"><Code2 size={15}/> CODE EXAMPLE</div>
          <pre className="code-block"><code>{lesson.code}</code></pre>
          <div className="lesson-actions"><Button variant="secondary" onClick={() => setLessonIndex(Math.max(0, lessonIndex - 1))} disabled={lessonIndex === 0}>Previous lesson</Button><Button onClick={markComplete} disabled={!!completed[lesson.key]}>{completed[lesson.key] ? 'Completed' : 'Mark as complete'} <CheckCircle2 size={15}/></Button>{lessonIndex < lessons.length - 1 && <Button variant="ghost" onClick={() => setLessonIndex(lessonIndex + 1)}>Next <ArrowRight size={15}/></Button>}</div>
        </Panel>
        <Panel className="lesson-tip"><div className="tip-icon"><BookOpen size={19}/></div><div><b>Learning suggestion</b><p>Try writing the example yourself, changing one part, and explaining why the output changes. Active recall builds stronger understanding than simply reading code.</p></div></Panel>
      </div>
    </div>
  </>;
}
