import { useEffect, useMemo, useState } from 'react';
import { ArrowLeft, Bookmark, Code2, Filter, History, Save, Search } from 'lucide-react';
import { codingProblems } from '../data/content';
import { useApp } from '../context/AppContext';
import { storageService } from '../services/storageService';
import { Badge, Button, EmptyState, PageHeader, Panel } from '../components/UI';

export default function Coding() {
  const { notify, logActivity, revision } = useApp();
  const [difficulty, setDifficulty] = useState('All');
  const [topic, setTopic] = useState('All');
  const [search, setSearch] = useState('');
  const [active, setActive] = useState(null);
  const [language, setLanguage] = useState('JavaScript');
  const [code, setCode] = useState('');
  const [submissions, setSubmissions] = useState([]);
  const topics = ['All', ...new Set(codingProblems.flatMap(problem => problem.topics))];
  const filtered = useMemo(() => codingProblems.filter(problem => (difficulty === 'All' || problem.difficulty === difficulty) && (topic === 'All' || problem.topics.includes(topic)) && problem.title.toLowerCase().includes(search.toLowerCase())), [difficulty, topic, search]);
  useEffect(() => { storageService.getAll('submissions').then(setSubmissions); }, [revision]);

  function starterFor(problem, selectedLanguage) {
    if (selectedLanguage === 'JavaScript') return problem.starter;
    const methodNames = { 'two-sum': ['twoSum', 'two_sum'], 'valid-palindrome': ['isPalindrome', 'is_palindrome'], 'binary-search': ['search', 'search'], 'max-subarray': ['maxSubArray', 'max_sub_array'], 'longest-substring': ['lengthOfLongestSubstring', 'length_of_longest_substring'] };
    const [camel, snake] = methodNames[problem.id] || ['solve', 'solve'];
    if (selectedLanguage === 'Python') return `def ${snake}(*args):
    # Write your solution here
    pass`;
    if (selectedLanguage === 'Java') return `class Solution {
    public Object ${camel}() {
        // Write your solution here
        return null;
    }
}`;
    if (selectedLanguage === 'C++') return `class Solution {
public:
    // Write your solution here
};`;
    return `/* Write your C solution for: ${problem.title} */
#include <stdio.h>

int main(void) {
    // Write your solution here
    return 0;
}`;
  }
  function openProblem(problem) { setActive(problem); setLanguage('JavaScript'); setCode(problem.starter); }
  async function saveSubmission() {
    if (!code.trim() || code === starterFor(active, language)) return notify('Write your solution before saving a submission.', 'error');
    const record = await storageService.put('submissions', { problemId: active.id, title: active.title, language, code, status: 'Saved for review', createdAt: new Date().toISOString() });
    await logActivity({ type: 'coding', label: `Saved a ${language} solution for ${active.title}` });
    setSubmissions(current => [record, ...current]);
    notify('Submission saved locally. Code execution is not enabled in this version.');
  }
  async function bookmark() {
    const all = await storageService.getAll('saved');
    if (all.some(item => item.problemId === active.id)) return notify('Problem already saved.', 'info');
    await storageService.put('saved', { type: 'Coding problem', problemId: active.id, question: active.title, category: active.topics.join(', '), description: active.description });
    notify('Problem added to Saved Questions.');
  }

  return <>
    <PageHeader eyebrow="PROBLEM SOLVING" title="Coding Practice" description="Explore curated problems, write solutions in your preferred language, and track your attempts locally." action={<Badge tone="orange">Local submission tracking</Badge>}/>
    {!active ? <><div className="coding-toolbar"><div className="search-field"><Search size={16}/><input value={search} onChange={e => setSearch(e.target.value)} placeholder="Search problems..."/></div><div className="filter-select"><Filter size={15}/><select value={difficulty} onChange={e => setDifficulty(e.target.value)}><option>All</option><option>Easy</option><option>Medium</option><option>Hard</option></select></div><div className="filter-select"><select value={topic} onChange={e => setTopic(e.target.value)}>{topics.map(item => <option key={item}>{item}</option>)}</select></div></div><Panel padding={false} className="problem-table"><div className="problem-table-head"><span>PROBLEM</span><span>TOPICS</span><span>DIFFICULTY</span><span>ATTEMPTS</span></div>{filtered.map(problem => <div className="problem-row" key={problem.id}><button className="problem-title" onClick={() => openProblem(problem)}><span className="problem-code-icon"><Code2 size={17}/></span><span><b>{problem.title}</b><small>Curated practice problem</small></span></button><div className="problem-topics">{problem.topics.map(item => <Badge key={item}>{item}</Badge>)}</div><div><Badge tone={problem.difficulty === 'Easy' ? 'green' : problem.difficulty === 'Medium' ? 'orange' : 'red'}>{problem.difficulty}</Badge></div><div className="attempt-count">{submissions.filter(item => item.problemId === problem.id).length} saved</div></div>)}{!filtered.length && <EmptyState title="No problems match" description="Try changing the search or filters."/>}</Panel><div className="coding-note"><Code2 size={17}/><span><strong>About code execution:</strong> This build provides a code editor and local submission history. It does not compile or execute code, so saved attempts are not marked as passed or failed.</span></div></> : <div className="editor-layout"><div className="editor-main"><button className="back-link" onClick={() => setActive(null)}><ArrowLeft size={15}/> Back to problem library</button><Panel className="problem-description"><div className="problem-detail-top"><Badge tone={active.difficulty === 'Easy' ? 'green' : active.difficulty === 'Medium' ? 'orange' : 'red'}>{active.difficulty}</Badge><button className="save-question" onClick={bookmark}><Bookmark size={15}/> Save problem</button></div><h2>{active.title}</h2><p>{active.description}</p><h4>Example</h4><pre className="sample-block">{active.example}</pre><div className="hint-block"><strong>Hint</strong><p>{active.hint}</p></div></Panel></div><Panel className="editor-panel" padding={false}><div className="editor-toolbar"><div><Code2 size={16}/> <strong>Code workspace</strong></div><select value={language} onChange={e => { setLanguage(e.target.value); setCode(starterFor(active, e.target.value)); }}>{['JavaScript', 'Python', 'Java', 'C++', 'C'].map(item => <option key={item}>{item}</option>)}</select></div><textarea className="code-editor" spellCheck="false" value={code} onChange={e => setCode(e.target.value)} /><div className="editor-footer"><span><span className="status-dot"/> Local draft</span><Button onClick={saveSubmission}><Save size={15}/> Save submission</Button></div><p className="editor-disclaimer">No compiler connected. Your code is stored locally for review.</p></Panel></div>}
    <Panel className="submission-history"><div className="section-title"><div><h2><History size={18}/> Recent submissions</h2><p>Your saved attempts from this browser</p></div></div>{submissions.slice(0, 4).map(item => <div className="submission-row" key={item.id}><div><b>{item.title}</b><small>{item.language} · {new Date(item.createdAt).toLocaleString()}</small></div><Badge tone="neutral">{item.status}</Badge></div>)}{!submissions.length && <p className="muted-text">Your saved submissions will appear here.</p>}</Panel>
  </>;
}
