import { useState } from 'react';
import { ArrowLeft, ArrowRight, Bookmark, CheckCircle2, MessageSquareText, RotateCcw, Sparkles, Trophy } from 'lucide-react';
import { useApp } from '../context/AppContext';
import { geminiService } from '../services/geminiService';
import { storageService } from '../services/storageService';
import { Badge, Button, Field, PageHeader, Panel, ProgressBar } from '../components/UI';

const initialSettings = { type: 'Technical', role: 'Software Developer', company: '', difficulty: 'Intermediate', count: 5 };

export default function Interview() {
  const { notify, logActivity, refresh, subscription } = useApp();
  const [settings, setSettings] = useState(initialSettings);
  const [phase, setPhase] = useState('setup');
  const [questions, setQuestions] = useState([]);
  const [index, setIndex] = useState(0);
  const [answer, setAnswer] = useState('');
  const [loading, setLoading] = useState(false);
  const [report, setReport] = useState(null);
  const [sessionId, setSessionId] = useState(null);
  const [evaluation, setEvaluation] = useState(null);

  async function startInterview(event) {
    event.preventDefault(); setLoading(true);
    try {
      const generated = await geminiService.generateInterviewQuestions(settings);
      setQuestions(generated.map(q => ({ ...q, answer: '', evaluation: null })));
      setIndex(0); setAnswer(''); setEvaluation(null); setReport(null); setPhase('interview');
    } catch (error) { notify(error.message, 'error'); }
    finally { setLoading(false); }
  }

  async function bookmarkQuestion() {
    const current = questions[index];
    if (!current) return;
    const items = await storageService.getAll('saved');
    if (items.some(item => item.questionId === current.id)) return notify('This interview question is already saved.', 'info');
    await storageService.put('saved', { type: 'Interview question', questionId: current.id, question: current.question, category: `${settings.type} · ${settings.role}` });
    refresh(); notify('Interview question added to Saved Questions.');
  }

  async function evaluateAnswer() {
    if (answer.trim().length < 20) return notify('Add a little more detail before evaluating (at least 20 characters).', 'error');
    setLoading(true);
    try {
      const result = await geminiService.evaluateInterviewAnswer({ question: questions[index].question, answer, role: settings.role, type: settings.type });
      setEvaluation(result);
      setQuestions(current => current.map((q, i) => i === index ? { ...q, answer, evaluation: result } : q));
    } catch (error) { notify(error.message, 'error'); }
    finally { setLoading(false); }
  }

  async function continueInterview() {
    if (index < questions.length - 1) {
      setIndex(index + 1); setAnswer(questions[index + 1].answer || ''); setEvaluation(questions[index + 1].evaluation || null);
      return;
    }
    setLoading(true);
    try {
      const finalReport = await geminiService.generateInterviewFeedback({ questions, role: settings.role, type: settings.type });
      const record = await storageService.put('sessions', { type: settings.type, role: settings.role, company: settings.company, difficulty: settings.difficulty, questions, report: finalReport, score: finalReport.overallScore, createdAt: new Date().toISOString() });
      setSessionId(record.id); setReport(finalReport); setPhase('report');
      await logActivity({ type: 'interview', label: `${settings.type} mock interview completed`, score: finalReport.overallScore });
      refresh();
    } catch (error) { notify(error.message, 'error'); }
    finally { setLoading(false); }
  }

  function goBack() { setPhase('setup'); setQuestions([]); setEvaluation(null); setReport(null); }

  return <>
    <PageHeader eyebrow="CAREER TOOLS / INTERVIEW PRACTICE" title="AI Mock Interview" description="Practise with tailored questions and get structured, actionable feedback from Gemini." action={<Badge tone="blue"><Sparkles size={12}/> Gemini powered</Badge>} />
    {phase === 'setup' && <div className="interview-setup-grid"><Panel className="setup-panel"><div className="panel-kicker"><MessageSquareText size={16}/> SESSION CONFIGURATION</div><h2>Design your interview.</h2><p>Choose a format and difficulty. Gemini will create a focused set of questions for your practice.</p><form onSubmit={startInterview} className="form-stack">
      <Field label="Interview type"><select value={settings.type} onChange={e => setSettings({ ...settings, type: e.target.value })}><option>Technical</option><option>HR</option><option>Behavioral</option><option>Company-specific</option></select></Field>
      <Field label="Target role"><input value={settings.role} onChange={e => setSettings({ ...settings, role: e.target.value })} placeholder="e.g. Frontend Developer" required/></Field>
      {settings.type === 'Company-specific' && <Field label="Company"><input value={settings.company} onChange={e => setSettings({ ...settings, company: e.target.value })} placeholder="e.g. Google, Microsoft" /></Field>}
      <div className="two-fields"><Field label="Difficulty"><select value={settings.difficulty} onChange={e => setSettings({ ...settings, difficulty: e.target.value })}><option>Beginner</option><option>Intermediate</option><option>Advanced</option></select></Field><Field label="Questions"><select value={settings.count} onChange={e => setSettings({ ...settings, count: Number(e.target.value) })}><option value={3}>3 questions</option><option value={5}>5 questions</option><option value={8} disabled={subscription.plan !== 'PRO'}>8 questions · PRO</option></select></Field></div>
      <Button type="submit" disabled={loading} className="full-width">{loading ? 'Preparing interview…' : 'Generate interview questions'} <ArrowRight size={16}/></Button>
    </form></Panel><Panel className="setup-aside"><div className="setup-orb"><Sparkles size={30}/></div><h3>What to expect</h3><div className="expect-list"><div><span>01</span><div><b>Tailored questions</b><small>Questions based on your role, interview type and difficulty.</small></div></div><div><span>02</span><div><b>Answer evaluation</b><small>Feedback on clarity, relevance, structure and examples.</small></div></div><div><span>03</span><div><b>Session report</b><small>Strengths, focus areas and a practical next-step plan.</small></div></div></div><div className="privacy-note"><CheckCircle2 size={16}/> Your interview reports are saved in this browser only.</div></Panel></div>}

    {phase === 'interview' && questions[index] && <div className="interview-workspace"><div className="interview-progress-row"><div><span className="eyebrow">{settings.type.toUpperCase()} INTERVIEW</span><strong>Question {index + 1} <small>of {questions.length}</small></strong></div><Badge tone="blue">{settings.difficulty}</Badge></div><ProgressBar value={(index / questions.length) * 100}/><Panel className="question-panel"><div className="question-meta"><span>QUESTION {String(index + 1).padStart(2, '0')}</span><span>{questions[index].category || settings.type}</span></div><h2>{questions[index].question}</h2>{questions[index].intent && <div className="question-intent"><Sparkles size={14}/> What this evaluates: {questions[index].intent}</div>}<Field label="Your answer"><textarea rows={9} value={answer} onChange={e => setAnswer(e.target.value)} placeholder="Structure your response clearly. Include an example, the action you took, and the outcome where relevant." /></Field><div className="answer-helper"><span>{answer.trim().split(/\s+/).filter(Boolean).length} words</span><span>Tip: Keep your answer specific and easy to follow.</span></div><div className="question-actions"><button className="save-question" onClick={bookmarkQuestion}><Bookmark size={15}/> Save question</button><Button variant="secondary" onClick={() => { setIndex(Math.max(0, index - 1)); setAnswer(questions[Math.max(0, index - 1)].answer || ''); setEvaluation(questions[Math.max(0, index - 1)].evaluation || null); }} disabled={index === 0}><ArrowLeft size={15}/> Previous</Button><Button onClick={evaluateAnswer} disabled={loading}>{loading ? 'Evaluating…' : 'Evaluate answer'} <Sparkles size={15}/></Button></div></Panel>
      {evaluation && <Panel className="evaluation-card"><div className="evaluation-head"><div><div className="ai-label"><Sparkles size={14}/> AI ANSWER REVIEW</div><h3>Your feedback</h3></div><div className="score-bubble"><strong>{evaluation.score}</strong><small>/100</small></div></div><p className="evaluation-summary">{evaluation.overallFeedback}</p><div className="feedback-columns"><div><h4>Strengths</h4>{evaluation.strengths.map((item, i) => <div className="feedback-item positive" key={i}><CheckCircle2 size={15}/>{item}</div>)}</div><div><h4>Growth areas</h4>{evaluation.weaknesses.map((item, i) => <div className="feedback-item caution" key={i}><span>•</span>{item}</div>)}</div></div><div className="suggestion-row"><strong>Suggestions</strong>{evaluation.suggestions.map((item, i) => <Badge key={i} tone="neutral">{item}</Badge>)}</div><Button className="continue-btn" onClick={continueInterview} disabled={loading}>{loading ? 'Preparing next step…' : index === questions.length - 1 ? 'Finish interview & view report' : 'Continue to next question'} <ArrowRight size={15}/></Button></Panel>}
    </div>}

    {phase === 'report' && report && <div className="report-wrap"><Panel className="report-hero"><div className="report-trophy"><Trophy size={26}/></div><div><div className="ai-label"><Sparkles size={14}/> INTERVIEW COMPLETE</div><h2>Your session report is ready.</h2><p>{report.summary}</p></div><div className="report-score"><strong>{report.overallScore}</strong><small>/100</small><Badge tone={report.overallScore >= 80 ? 'green' : report.overallScore >= 60 ? 'blue' : 'orange'}>{report.readiness}</Badge></div></Panel><div className="report-grid"><Panel><h3>What went well</h3>{report.strengths.map((item, i) => <div className="feedback-item positive" key={i}><CheckCircle2 size={15}/>{item}</div>)}</Panel><Panel><h3>Focus areas</h3>{report.focusAreas.map((item, i) => <div className="feedback-item caution" key={i}><span>•</span>{item}</div>)}</Panel></div><Panel><h3>Your action plan</h3><div className="action-plan">{report.actionPlan.map((item, i) => <div key={i}><span>{String(i + 1).padStart(2, '0')}</span>{item}</div>)}</div><div className="report-actions"><Button variant="secondary" onClick={goBack}><RotateCcw size={15}/> New interview</Button><Button onClick={() => window.location.assign('/history')}>View interview history <ArrowRight size={15}/></Button></div></Panel><div className="report-footnote"><CheckCircle2 size={15}/> This is AI-generated practice feedback, not a hiring decision or a guarantee of interview performance.</div></div>}
  </>;
}
