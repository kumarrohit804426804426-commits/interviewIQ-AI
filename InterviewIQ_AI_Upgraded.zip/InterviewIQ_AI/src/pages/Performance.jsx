import { useEffect, useMemo, useState } from 'react';
import { Activity, Award, BookOpen, Code2, MessageSquareText, Target, TrendingUp } from 'lucide-react';
import { Bar, BarChart, CartesianGrid, ResponsiveContainer, Tooltip, XAxis, YAxis } from 'recharts';
import { storageService } from '../services/storageService';
import { useApp } from '../context/AppContext';
import { Badge, EmptyState, PageHeader, Panel, ProgressBar, StatCard } from '../components/UI';

export default function Performance() {
  const { revision } = useApp();
  const [activity, setActivity] = useState([]);
  const [quizzes, setQuizzes] = useState([]);
  const [sessions, setSessions] = useState([]);
  const [progress, setProgress] = useState([]);
  const [submissions, setSubmissions] = useState([]);
  useEffect(() => { Promise.all(['activity', 'quizzes', 'sessions', 'progress', 'submissions'].map(name => storageService.getAll(name))).then(([a, q, s, p, c]) => { setActivity(a); setQuizzes(q); setSessions(s); setProgress(p); setSubmissions(c); }); }, [revision]);
  const average = quizzes.length ? Math.round(quizzes.reduce((sum, q) => sum + q.percentage, 0) / quizzes.length) : 0;
  const weekly = useMemo(() => Array.from({ length: 7 }, (_, i) => {
    const d = new Date(); d.setDate(d.getDate() - 6 + i); d.setHours(0, 0, 0, 0); const end = new Date(d); end.setDate(end.getDate() + 1);
    return { day: d.toLocaleDateString('en-US', { weekday: 'short' }), activity: activity.filter(a => new Date(a.createdAt) >= d && new Date(a.createdAt) < end).length };
  }), [activity]);
  const categories = [
    { name: 'Interview practice', value: sessions.length, target: 8, icon: MessageSquareText, color: 'blue' },
    { name: 'Coding submissions', value: submissions.length, target: 12, icon: Code2, color: 'purple' },
    { name: 'Lessons completed', value: progress.length, target: 12, icon: BookOpen, color: 'green' },
    { name: 'Quiz practice', value: quizzes.length, target: 10, icon: Target, color: 'orange' },
  ];
  return <>
    <PageHeader eyebrow="YOUR GROWTH" title="Performance Tracker" description="Understand your consistency, practice outcomes and learning progress at a glance." action={<Badge tone="blue">Browser activity</Badge>}/>
    <div className="stats-grid four"><StatCard label="Activities logged" value={activity.length} icon={Activity} tone="blue" change="Across your workspace"/><StatCard label="Average quiz score" value={`${average}%`} icon={Award} tone="green" change={`${quizzes.length} quiz records`}/><StatCard label="Interview sessions" value={sessions.length} icon={MessageSquareText} tone="violet" change="Saved reports"/><StatCard label="Coding attempts" value={submissions.length} icon={Code2} tone="orange" change="Saved submissions"/></div>
    <div className="dashboard-grid"><Panel><div className="section-title"><div><h2>Weekly consistency</h2><p>Number of recorded learning activities</p></div><Badge tone="blue">Last 7 days</Badge></div><div className="chart-area tall"><ResponsiveContainer width="100%" height="100%"><BarChart data={weekly} margin={{ top: 12, right: 8, left: -24, bottom: 0 }}><CartesianGrid strokeDasharray="3 5" vertical={false} stroke="#edf0f4"/><XAxis dataKey="day" axisLine={false} tickLine={false} tick={{ fill: '#9699a1', fontSize: 12 }}/><YAxis allowDecimals={false} axisLine={false} tickLine={false} tick={{ fill: '#9699a1', fontSize: 12 }}/><Tooltip contentStyle={{ border: '1px solid #edf0f4', borderRadius: 12 }}/><Bar dataKey="activity" fill="#1684ff" radius={[7, 7, 0, 0]} maxBarSize={34}/></BarChart></ResponsiveContainer></div></Panel><Panel><div className="section-title"><div><h2>Skill-wise analytics</h2><p>Progress towards starter targets</p></div></div><div className="skill-progress-list">{categories.map(item => { const Icon = item.icon; const percent = Math.min(100, Math.round(item.value / item.target * 100)); return <div key={item.name}><div className="skill-progress-heading"><span><i className={`skill-icon ${item.color}`}><Icon size={14}/></i>{item.name}</span><strong>{item.value}/{item.target}</strong></div><ProgressBar value={percent} color={item.color}/></div>; })}</div></Panel></div>
    <Panel className="trend-panel"><div className="section-title"><div><h2>Recent performance records</h2><p>Latest quiz scores and interview outcomes</p></div></div>{[...quizzes.map(q => ({ ...q, kind: q.type || 'Quiz', date: q.createdAt, result: `${q.percentage}%`, score: q.percentage })), ...sessions.map(s => ({ ...s, kind: `${s.type} interview`, date: s.createdAt, result: `${s.score || 0}/100`, score: s.score }))].sort((a, b) => new Date(b.date) - new Date(a.date)).slice(0, 8).map((item, i) => <div className="performance-row" key={`${item.id || i}-${item.kind}`}><div><b>{item.kind}</b><small>{new Date(item.date).toLocaleString()}</small></div><div className="performance-result"><strong>{item.result}</strong><div className="tiny-bar"><span style={{ width: `${item.score}%` }}/></div></div></div>)}{!quizzes.length && !sessions.length && <EmptyState title="No scored sessions yet" description="Your interview reports and quiz attempts will appear here."/>}</Panel>
    <div className="data-footnote"><TrendingUp size={16}/> Metrics are calculated from activity stored in this browser. Demo activity may be included to make the workspace easier to preview.</div>
  </>;
}
