import { useEffect, useMemo, useState } from 'react';
import { Bookmark, Search, Trash2, BookOpen, Code2, MessageSquareText } from 'lucide-react';
import { storageService } from '../services/storageService';
import { useApp } from '../context/AppContext';
import { Badge, EmptyState, PageHeader, Panel } from '../components/UI';

export default function Saved() {
  const { notify, revision, refresh } = useApp();
  const [items, setItems] = useState([]);
  const [search, setSearch] = useState('');
  const [type, setType] = useState('All');
  useEffect(() => { storageService.getAll('saved').then(setItems); }, [revision]);
  const types = ['All', ...new Set(items.map(item => item.type || 'Other'))];
  const filtered = useMemo(() => items.filter(item => (type === 'All' || item.type === type) && `${item.question || ''} ${item.category || ''} ${item.description || ''}`.toLowerCase().includes(search.toLowerCase())), [items, type, search]);
  async function remove(item) { await storageService.remove('saved', item.id); setItems(current => current.filter(row => row.id !== item.id)); refresh(); notify('Removed from Saved Questions.'); }
  const iconFor = item => item.type?.includes('Coding') ? Code2 : item.type?.includes('Interview') ? MessageSquareText : BookOpen;
  return <>
    <PageHeader eyebrow="PERSONAL LIBRARY" title="Saved Questions" description="Keep useful interview prompts, GATE questions and coding problems in one place." action={<Badge tone="blue">{items.length} saved</Badge>}/>
    <div className="saved-toolbar"><div className="search-field"><Search size={16}/><input value={search} onChange={e => setSearch(e.target.value)} placeholder="Search your saved items..."/></div><div className="filter-chip-row">{types.map(item => <button key={item} className={`filter-chip ${type === item ? 'active' : ''}`} onClick={() => setType(item)}>{item}</button>)}</div></div>
    {filtered.length ? <div className="saved-grid">{filtered.map(item => { const Icon = iconFor(item); return <Panel className="saved-card" key={item.id}><div className="saved-card-top"><span className="saved-type-icon"><Icon size={17}/></span><Badge>{item.type || 'Saved item'}</Badge><button className="icon-btn danger" onClick={() => remove(item)} aria-label="Remove saved item"><Trash2 size={16}/></button></div><h3>{item.question || item.title || 'Saved item'}</h3>{item.description && <p>{item.description}</p>}{item.category && <small className="saved-category">{item.category}</small>}{item.options && <div className="saved-options">{item.options.map((option, i) => <span key={i}>{String.fromCharCode(65 + i)}. {option}</span>)}</div>}{item.explanation && <details><summary>View explanation</summary><p>{item.explanation}</p></details>}<div className="saved-date">Saved {new Date(item.createdAt || item.updatedAt).toLocaleDateString()}</div></Panel>; })}</div> : <Panel><EmptyState icon={Bookmark} title={items.length ? 'No matching saved items' : 'Your saved library is empty'} description={items.length ? 'Try a different search or filter.' : 'Use the bookmark action on interview, GATE or coding content to keep it here.'}/></Panel>}
  </>;
}
