import { useEffect, useState } from 'react';
import { BookOpen, Database, Plus, ShieldCheck, Trash2, Users, MessageSquareText } from 'lucide-react';
import { useApp } from '../context/AppContext';
import { storageService } from '../services/storageService';
import { programmingPaths } from '../data/content';
import { Badge, Button, Field, PageHeader, Panel } from '../components/UI';

const YEARS = Array.from({ length: 40 }, (_, index) => String(2026 - index));

export default function Admin() {
  const { profile, role, subscription, notify, revision, refresh } = useApp();
  const [stats, setStats] = useState({ sessions: [], quizzes: [], saved: [], progress: [], content: [] });
  const [question, setQuestion] = useState('');
  const [category, setCategory] = useState('programming');
  const [optionsText, setOptionsText] = useState('');
  const [correctAnswer, setCorrectAnswer] = useState('0');
  const [explanation, setExplanation] = useState('');
  const [questionYear, setQuestionYear] = useState('practice');
  const [lessonForm, setLessonForm] = useState({ language: 'JavaScript', title: '', description: '', code: '' });

  useEffect(() => {
    Promise.all(['sessions', 'quizzes', 'saved', 'progress', 'adminContent'].map(name => storageService.getAll(name)))
      .then(([sessions, quizzes, saved, progress, content]) => setStats({ sessions, quizzes, saved, progress, content }));
  }, [revision]);

  if (role !== 'admin') return <Panel><div className="empty-state"><ShieldCheck size={28}/><h3>Admin preview is disabled.</h3><p>Enable the demonstration admin role in Settings to view this page.</p></div></Panel>;

  async function addQuestion(event) {
    event.preventDefault();
    const options = optionsText.split('\n').map(value => value.trim()).filter(Boolean);
    if (question.trim().length < 8 || options.length !== 4 || !explanation.trim()) return notify('Add a question, exactly four options, and an explanation.', 'error');
    const item = await storageService.put('adminContent', {
      question: question.trim(), subject: category, topic: 'Admin-added practice', options,
      answer: Number(correctAnswer), explanation: explanation.trim(), type: 'gateQuestion',
      year: questionYear === 'practice' ? null : Number(questionYear), createdAt: new Date().toISOString(),
    });
    setStats(current => ({ ...current, content: [item, ...current.content] }));
    setQuestion(''); setOptionsText(''); setExplanation(''); setQuestionYear('practice');
    refresh(); notify('Question added to the local GATE practice bank.');
  }

  async function addLesson(event) {
    event.preventDefault();
    if (lessonForm.title.trim().length < 3 || lessonForm.description.trim().length < 10 || lessonForm.code.trim().length < 5) {
      return notify('Add a lesson title, a clear description, and a code example.', 'error');
    }
    const item = await storageService.put('adminContent', {
      type: 'customLesson', language: lessonForm.language, title: lessonForm.title.trim(),
      description: lessonForm.description.trim(), code: lessonForm.code.trim(), createdAt: new Date().toISOString(),
    });
    setStats(current => ({ ...current, content: [item, ...current.content] }));
    setLessonForm(current => ({ ...current, title: '', description: '', code: '' }));
    refresh(); notify('Lesson published to the local learning path.');
  }

  async function removeContent(item) {
    await storageService.remove('adminContent', item.id);
    setStats(current => ({ ...current, content: current.content.filter(row => row.id !== item.id) }));
    refresh(); notify(item.type === 'customLesson' ? 'Custom lesson removed.' : 'Demo question removed.');
  }
  async function removeQuiz(item) {
    await storageService.remove('quizzes', item.id);
    setStats(current => ({ ...current, quizzes: current.quizzes.filter(row => row.id !== item.id) }));
    refresh(); notify('Quiz record removed.');
  }
  async function removeProgress(item) {
    await storageService.remove('progress', item.id);
    setStats(current => ({ ...current, progress: current.progress.filter(row => row.id !== item.id) }));
    refresh(); notify('Learning progress record removed.');
  }

  const customLessons = stats.content.filter(item => item.type === 'customLesson');
  const customQuestions = stats.content.filter(item => item.type === 'gateQuestion');

  return <>
    <PageHeader eyebrow="ADMINISTRATION / DEMO MODE" title="Admin Panel" description="A local demonstration view for platform metrics and sample content management." action={<Badge tone="orange"><ShieldCheck size={12}/> Demo role only</Badge>}/>
    <div className="admin-warning"><ShieldCheck size={17}/><span>Important: this role check happens in the frontend and is not a secure production authorization system. Do not use it to protect real user data.</span></div>
    <div className="stats-grid four">
      <div className="admin-stat"><Users size={18}/><span>Demo profile</span><strong>1</strong></div>
      <div className="admin-stat"><MessageSquareText size={18}/><span>Mock interviews</span><strong>{stats.sessions.length}</strong></div>
      <div className="admin-stat"><BookOpen size={18}/><span>Saved questions</span><strong>{stats.saved.length}</strong></div>
      <div className="admin-stat"><Database size={18}/><span>Learning records</span><strong>{stats.progress.length + stats.quizzes.length}</strong></div>
    </div>
    <div className="dashboard-grid">
      <Panel>
        <div className="section-title"><div><h2>Demo user management</h2><p>Current local profile on this browser</p></div><Badge>1 local profile</Badge></div>
        <div className="admin-user-row"><div className="avatar">{(profile.name || 'L')[0].toUpperCase()}</div><div><b>{profile.name || 'Learner'}</b><small>{profile.email || 'No email supplied'} · Student profile</small></div><Badge tone="green">Active demo</Badge></div>
        <p className="muted-text">There is no server-side user database in this version. This panel only displays the active browser profile.</p>
      </Panel>
      <Panel>
        <div className="section-title"><div><h2>Subscription overview</h2><p>Checkout simulation</p></div></div>
        <div className="admin-subscription"><strong>Demo plan state</strong><Badge tone="blue">{subscription.plan} · {subscription.status}</Badge><p>Plan status is stored in this browser and does not represent a paid transaction. Quiz records currently stored: {stats.quizzes.length}.</p></div>
      </Panel>
    </div>

    <div className="admin-content-grid">
      <Panel>
        <div className="section-title"><div><h2>Question bank management</h2><p>Add GATE-style MCQs and optionally tag a verified paper year.</p></div></div>
        <form className="form-stack" onSubmit={addQuestion}>
          <Field label="Question"><textarea rows={3} value={question} onChange={event => setQuestion(event.target.value)} placeholder="Enter a GATE-style MCQ question..."/></Field>
          <Field label="Subject"><select value={category} onChange={event => setCategory(event.target.value)}><option value="programming">Programming & Data Structures</option><option value="algorithms">Algorithms</option><option value="dbms">DBMS</option><option value="os">Operating Systems</option><option value="networks">Computer Networks</option><option value="maths">Engineering Mathematics</option></select></Field>
          <Field label="Paper year"><select value={questionYear} onChange={event => setQuestionYear(event.target.value)}><option value="practice">Practice question · no PYQ claim</option>{YEARS.map(year => <option key={year} value={year}>{year}</option>)}</select></Field>
          <Field label="Four options (one per line)"><textarea rows={4} value={optionsText} onChange={event => setOptionsText(event.target.value)} placeholder={'Option A\nOption B\nOption C\nOption D'}/></Field>
          <Field label="Correct option"><select value={correctAnswer} onChange={event => setCorrectAnswer(event.target.value)}><option value="0">A</option><option value="1">B</option><option value="2">C</option><option value="3">D</option></select></Field>
          <Field label="Explanation"><textarea rows={2} value={explanation} onChange={event => setExplanation(event.target.value)} placeholder="Explain why the correct answer is right..."/></Field>
          <Button type="submit"><Plus size={15}/> Add question</Button>
        </form>
      </Panel>
      <Panel>
        <div className="section-title"><div><h2>Managed question bank</h2><p>Custom questions stored in this browser</p></div><Badge>{customQuestions.length} items</Badge></div>
        {customQuestions.map(item => <div className="admin-content-row" key={item.id}><div><b>{item.question}</b><small>{item.subject} · {item.year || 'Practice set'} · {new Date(item.createdAt).toLocaleDateString()}</small></div><button className="icon-btn danger" onClick={() => removeContent(item)} aria-label="Remove question"><Trash2 size={15}/></button></div>)}
        {!customQuestions.length && <p className="muted-text">No additional demo questions have been added.</p>}
      </Panel>
    </div>

    <div className="admin-content-grid">
      <Panel>
        <div className="section-title"><div><h2>Learning content management</h2><p>Create local lessons that appear in the selected programming path.</p></div><Badge>{customLessons.length} custom lessons</Badge></div>
        <form className="form-stack" onSubmit={addLesson}>
          <Field label="Programming language"><select value={lessonForm.language} onChange={event => setLessonForm({ ...lessonForm, language: event.target.value })}>{programmingPaths.map(path => <option key={path.language}>{path.language}</option>)}</select></Field>
          <Field label="Lesson title"><input value={lessonForm.title} onChange={event => setLessonForm({ ...lessonForm, title: event.target.value })} placeholder="e.g. Working with APIs"/></Field>
          <Field label="Lesson description"><textarea rows={3} value={lessonForm.description} onChange={event => setLessonForm({ ...lessonForm, description: event.target.value })} placeholder="What should the learner understand?"/></Field>
          <Field label="Code example"><textarea rows={5} value={lessonForm.code} onChange={event => setLessonForm({ ...lessonForm, code: event.target.value })} placeholder="Add a short code example..."/></Field>
          <Button type="submit"><Plus size={15}/> Publish lesson</Button>
        </form>
      </Panel>
      <Panel>
        <div className="section-title"><div><h2>Learning catalogue</h2><p>Starter paths and custom lessons published in this browser</p></div><Badge>{programmingPaths.length} paths</Badge></div>
        {programmingPaths.map(path => <div className="admin-content-row" key={path.language}><div><b>{path.language} · {path.tone}</b><small>{path.lessons.length + customLessons.filter(item => item.language === path.language).length} lessons · Local content</small></div><Badge tone="green">Published</Badge></div>)}
        {customLessons.map(item => <div className="admin-content-row" key={item.id}><div><b>{item.language} · {item.title}</b><small>Custom lesson · {new Date(item.createdAt).toLocaleDateString()}</small></div><button className="icon-btn danger" onClick={() => removeContent(item)} aria-label="Remove lesson"><Trash2 size={15}/></button></div>)}
      </Panel>
    </div>

    <div className="admin-content-grid">
      <Panel>
        <div className="section-title"><div><h2>Progress records</h2><p>Remove a local completion entry</p></div><Badge>{stats.progress.length}</Badge></div>
        {stats.progress.slice(0, 8).map(item => <div className="admin-content-row" key={item.id}><div><b>{item.title}</b><small>{item.language || item.category} · {new Date(item.createdAt || item.updatedAt).toLocaleDateString()}</small></div><button className="icon-btn danger" onClick={() => removeProgress(item)} aria-label="Remove progress record"><Trash2 size={15}/></button></div>)}
        {!stats.progress.length && <p className="muted-text">No progress records to manage.</p>}
      </Panel>
      <Panel>
        <div className="section-title"><div><h2>Quiz management</h2><p>Local quiz and practice records</p></div><Badge>{stats.quizzes.length} records</Badge></div>
        {stats.quizzes.map(item => <div className="admin-content-row" key={item.id}><div><b>{item.type || 'Quiz'} · {item.subject || 'Mixed'}</b><small>{item.score}/{item.total} correct · {new Date(item.createdAt).toLocaleDateString()}</small></div><div className="admin-quiz-actions"><Badge tone={item.percentage >= 70 ? 'green' : 'orange'}>{item.percentage}%</Badge><button className="icon-btn danger" onClick={() => removeQuiz(item)} aria-label="Remove quiz record"><Trash2 size={15}/></button></div></div>)}
        {!stats.quizzes.length && <p className="muted-text">No quiz records are available.</p>}
      </Panel>
    </div>
  </>;
}
