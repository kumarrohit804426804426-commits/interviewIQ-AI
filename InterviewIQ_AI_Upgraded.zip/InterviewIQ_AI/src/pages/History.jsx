import { useEffect, useState } from 'react';
import { CalendarDays, ChevronDown, ChevronUp, History as HistoryIcon, MessageSquareText, Trash2 } from 'lucide-react';
import { storageService } from '../services/storageService';
import { useApp } from '../context/AppContext';
import { Badge, EmptyState, PageHeader, Panel } from '../components/UI';

export default function History() {
  const { revision, refresh, notify } = useApp();
  const [sessions, setSessions] = useState([]);
  const [expanded, setExpanded] = useState(null);
  useEffect(() => { storageService.getAll('sessions').then(setSessions); }, [revision]);
  async function remove(session) { await storageService.remove('sessions', session.id); setSessions(current => current.filter(item => item.id !== session.id)); refresh(); notify('Interview report removed.'); }
  return <>
    <PageHeader eyebrow="PERSONAL RECORDS" title="Interview History" description="Revisit your mock interviews, question-by-question feedback and overall reports." action={<Badge tone="blue">{sessions.length} sessions</Badge>}/>
    {!sessions.length ? <Panel><EmptyState icon={HistoryIcon} title="No interview sessions yet" description="Complete an AI mock interview and its report will be saved here."/></Panel> : <div className="history-list">{sessions.map(session => <Panel className="history-card" key={session.id}><div className="history-card-main"><div className="history-symbol"><MessageSquareText size={20}/></div><div className="history-info"><div className="history-tags"><Badge tone="blue">{session.type}</Badge><Badge>{session.difficulty}</Badge></div><h3>{session.role || 'Software Developer'}{session.company ? ` · ${session.company}` : ''}</h3><p><CalendarDays size={13}/> {new Date(session.createdAt).toLocaleString()} <span>·</span> {session.questions?.length || 0} questions</p></div><div className="history-score"><strong>{session.score ?? '—'}</strong><small>/100</small></div><button className="icon-btn danger" onClick={() => remove(session)} aria-label="Delete session"><Trash2 size={16}/></button><button className="icon-btn" onClick={() => setExpanded(expanded === session.id ? null : session.id)} aria-label="Expand report">{expanded === session.id ? <ChevronUp size={18}/> : <ChevronDown size={18}/>}</button></div>
      {expanded === session.id && <div className="history-expanded"><div className="history-report-summary"><b>Overall feedback</b><p>{session.report?.summary || session.report?.overallFeedback || 'No summary saved.'}</p></div><div className="history-question-list">{(session.questions || []).map((q, i) => <div className="history-question" key={q.id || i}><div><b>{i + 1}. {q.question}</b><p>{q.answer || 'No answer recorded.'}</p></div>{q.evaluation && <Badge tone={q.evaluation.score >= 70 ? 'green' : 'orange'}>{q.evaluation.score}/100</Badge>}</div>)}</div>{session.report?.actionPlan?.length > 0 && <div className="history-actions"><b>Action plan</b><ul>{session.report.actionPlan.map((action, i) => <li key={i}>{action}</li>)}</ul></div>}</div>}</Panel>)}</div>}
  </>;
}
