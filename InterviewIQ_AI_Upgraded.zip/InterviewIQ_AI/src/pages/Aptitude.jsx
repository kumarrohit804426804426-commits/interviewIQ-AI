import { useEffect, useMemo, useState } from 'react';
import { ArrowRight, BrainCircuit, CheckCircle2, Clock3, Lightbulb, RotateCcw, Sparkles } from 'lucide-react';
import { aptitudeQuestions } from '../data/content';
import { useApp } from '../context/AppContext';
import { storageService } from '../services/storageService';
import { geminiService } from '../services/geminiService';
import { Badge, Button, PageHeader, Panel, ProgressBar } from '../components/UI';

const CATEGORIES = ['All categories', 'Quantitative Aptitude', 'Logical Reasoning', 'Verbal Ability'];
export default function Aptitude() {
  const { notify, logActivity } = useApp();
  const [category, setCategory] = useState('All categories');
  const [active, setActive] = useState(false);
  const [answers, setAnswers] = useState({});
  const [index, setIndex] = useState(0);
  const [seconds, setSeconds] = useState(600);
  const [result, setResult] = useState(false);
  const [explanation, setExplanation] = useState(null);
  const [explaining, setExplaining] = useState(false);
  const questions = useMemo(() => aptitudeQuestions.filter(q => category === 'All categories' || q.category === category), [category]);
  const current = questions[index];
  const score = questions.filter(q => answers[q.id] === q.answer).length;
  const answeredCount = Object.keys(answers).length;

  useEffect(() => {
    if (!active || result) return undefined;
    const timer = window.setInterval(() => setSeconds(value => Math.max(0, value - 1)), 1000);
    return () => window.clearInterval(timer);
  }, [active, result]);

  useEffect(() => {
    if (active && seconds === 0 && !result) finish();
  }, [active, seconds, result]);

  function start() { setAnswers({}); setIndex(0); setSeconds(600); setResult(false); setExplanation(null); setActive(true); }
  async function finish() {
    setResult(true); setActive(false);
    const percentage = Math.round(score / questions.length * 100);
    await storageService.put('quizzes', { type: 'Aptitude & Reasoning', subject: category, score, total: questions.length, percentage, answers: questions.map(q => ({ questionId: q.id, selected: answers[q.id], correct: q.answer })), createdAt: new Date().toISOString() });
    await logActivity({ type: 'quiz', label: `Completed aptitude practice · ${category}`, score: percentage });
    notify('Your aptitude result has been saved.');
  }
  async function askAI() {
    if (!current) return;
    setExplaining(true);
    try { setExplanation(await geminiService.explainAptitudeAnswer({ question: current.question, options: current.options, correctAnswer: current.options[current.answer], explanation: current.explanation, selectedAnswer: current.options[answers[current.id]] || 'Not answered' })); }
    catch (error) { notify(error.message, 'error'); }
    finally { setExplaining(false); }
  }
  const timeText = `${String(Math.floor(seconds / 60)).padStart(2, '0')}:${String(seconds % 60).padStart(2, '0')}`;

  return <>
    <PageHeader eyebrow="SKILL ASSESSMENT" title="Aptitude & Reasoning" description="Sharpen quantitative, logical and verbal ability with timed MCQ practice." action={<Badge tone="green"><Clock3 size={12}/> 10-minute practice</Badge>}/>
    {!active && !result && <><div className="category-filter-row">{CATEGORIES.map(item => <button key={item} className={`filter-chip ${category === item ? 'active' : ''}`} onClick={() => setCategory(item)}>{item}</button>)}</div><div className="aptitude-start-grid"><Panel className="aptitude-start-card"><div className="aptitude-big-icon"><BrainCircuit size={27}/></div><div className="eyebrow">PRACTICE SESSION</div><h2>Test your reasoning skills.</h2><p>Answer a short practice set, review explanations, and track your score over time.</p><div className="aptitude-meta"><span><Clock3 size={14}/> 10 minutes</span><span><CheckCircle2 size={14}/> {questions.length} questions</span><span><Sparkles size={14}/> Instant scoring</span></div><Button onClick={start}>Start practice <ArrowRight size={15}/></Button></Panel><Panel className="aptitude-categories"><h3>Practice areas</h3>{['Quantitative Aptitude', 'Logical Reasoning', 'Verbal Ability'].map((item, i) => <button key={item} onClick={() => setCategory(item)}><span className={`category-mini-icon category-${i}`}>{i === 0 ? '∑' : i === 1 ? '◈' : 'Aa'}</span><span><b>{item}</b><small>{aptitudeQuestions.filter(q => q.category === item).length} sample questions</small></span><ArrowRight size={15}/></button>)}</Panel></div></>}

    {active && current && <div className="aptitude-layout"><div className="aptitude-main"><Panel className="aptitude-question-panel"><div className="aptitude-test-top"><span>QUESTION {index + 1} / {questions.length}</span><div className={`timer-pill ${seconds < 90 ? 'urgent' : ''}`}><Clock3 size={15}/> {timeText}</div></div><ProgressBar value={(index + 1) / questions.length * 100}/><Badge tone="blue">{current.category}</Badge><h2>{current.question}</h2><div className="options-list">{current.options.map((option, i) => <button key={option} className={`option-button ${answers[current.id] === i ? 'selected' : ''}`} onClick={() => { setAnswers({ ...answers, [current.id]: i }); setExplanation(null); }}><span className="option-key">{String.fromCharCode(65 + i)}</span>{option}</button>)}</div><div className="aptitude-actions"><Button variant="secondary" onClick={() => setIndex(Math.max(0, index - 1))} disabled={index === 0}>Previous</Button>{index === questions.length - 1 ? <Button onClick={finish}>Submit answers <CheckCircle2 size={15}/></Button> : <Button onClick={() => setIndex(index + 1)} disabled={answers[current.id] === undefined}>Next <ArrowRight size={15}/></Button>}</div></Panel><Panel className="explanation-panel"><div className="explanation-title"><Lightbulb size={17}/><b>Understand the answer</b></div><p>{current.explanation}</p><Button variant="secondary" size="sm" onClick={askAI} disabled={explaining}>{explaining ? 'Generating explanation…' : 'Explain with Gemini'} <Sparkles size={14}/></Button>{explanation && <div className="ai-explanation"><strong>{explanation.keyIdea}</strong><ol>{(explanation.steps || []).map((step, i) => <li key={i}>{step}</li>)}</ol><p>{explanation.tip}</p></div>}</Panel></div><aside className="quiz-aside"><Panel><h3>Question navigator</h3><div className="question-dots">{questions.map((q, i) => <button key={q.id} onClick={() => setIndex(i)} className={`${index === i ? 'current' : ''} ${answers[q.id] !== undefined ? 'answered' : ''}`}>{i + 1}</button>)}</div><div className="navigator-legend"><span><i className="answered-dot"/> Answered</span><span><i/> Unanswered</span></div><div className="navigator-progress"><div><span>Progress</span><b>{answeredCount}/{questions.length}</b></div><ProgressBar value={answeredCount / questions.length * 100}/></div><Button variant="secondary" className="full-width" onClick={finish}>Finish early</Button></Panel></aside></div>}

    {result && <div className="aptitude-result"><Panel className="result-hero"><div className="result-score-ring"><strong>{Math.round(score / questions.length * 100)}<small>%</small></strong></div><div><div className="eyebrow">PRACTICE COMPLETED</div><h2>{score >= questions.length * .75 ? 'Strong effort. Keep building on it.' : 'Good practice. Review and improve.'}</h2><p>You answered {score} out of {questions.length} questions correctly.</p><Badge tone={score >= questions.length * .75 ? 'green' : 'orange'}>{score >= questions.length * .75 ? 'On track' : 'Keep practising'}</Badge></div><Button onClick={start}><RotateCcw size={15}/> Try again</Button></Panel>{questions.map((q, i) => <Panel className="answer-review" key={q.id}><div className="review-question"><span>{String(i + 1).padStart(2, '0')}</span><b>{q.question}</b><Badge tone={answers[q.id] === q.answer ? 'green' : 'red'}>{answers[q.id] === q.answer ? 'Correct' : 'Incorrect'}</Badge></div><div className="review-explanation"><b>Answer: {q.options[q.answer]}</b><p>{q.explanation}</p></div></Panel>)}</div>}
  </>;
}
