import { useState } from 'react';
import { Bell, Download, RefreshCcw, ShieldCheck, UserCog } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { useApp } from '../context/AppContext';
import { storageService } from '../services/storageService';
import { Badge, Button, PageHeader, Panel } from '../components/UI';

export default function Settings() {
  const { preferences, updatePreferences, role, updateRole, notify, refresh } = useApp();
  const [resetting, setResetting] = useState(false);
  const navigate = useNavigate();
  async function exportData() {
    try {
      const data = await storageService.exportAll();
      const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
      const url = URL.createObjectURL(blob); const link = document.createElement('a');
      link.href = url; link.download = `interviewiq-backup-${new Date().toISOString().slice(0, 10)}.json`; link.click(); URL.revokeObjectURL(url);
      notify('Your data export has been created.');
    } catch (error) { notify(error.message, 'error'); }
  }
  async function resetData() {
    if (!window.confirm('Reset all InterviewIQ demo data stored in this browser? This cannot be undone.')) return;
    setResetting(true);
    try { await storageService.resetDemoData(); await storageService.seed(); refresh(); notify('Demo data reset. Reloading your workspace.'); window.setTimeout(() => window.location.assign('/'), 500); }
    catch (error) { notify(error.message, 'error'); }
    finally { setResetting(false); }
  }
  return <>
    <PageHeader eyebrow="WORKSPACE PREFERENCES" title="Settings" description="Manage your local preferences, privacy controls and demonstration settings." action={<Badge>Light appearance</Badge>}/>
    <div className="settings-layout"><div className="settings-main"><Panel className="settings-card"><div className="settings-card-heading"><div className="settings-icon"><Bell size={18}/></div><div><h3>Notifications</h3><p>Choose which reminders appear in this workspace.</p></div></div><div className="settings-option"><div><b>Practice reminders</b><small>Show lightweight reminders to continue your preparation.</small></div><button className={`toggle ${preferences.notifications ? 'on' : ''}`} onClick={() => updatePreferences({ notifications: !preferences.notifications })} aria-label="Toggle practice reminders"><span/></button></div><div className="settings-option"><div><b>Weekly learning summary</b><small>Include a weekly progress overview on the dashboard.</small></div><button className={`toggle ${preferences.weeklySummary ? 'on' : ''}`} onClick={() => updatePreferences({ weeklySummary: !preferences.weeklySummary })} aria-label="Toggle weekly summary"><span/></button></div></Panel><Panel className="settings-card"><div className="settings-card-heading"><div className="settings-icon"><ShieldCheck size={18}/></div><div><h3>Privacy & storage</h3><p>Your learning data is stored in this browser.</p></div></div><div className="settings-option"><div><b>Local browser database</b><small>IndexedDB stores practice history, saved items and learning progress.</small></div><Badge tone="green">Enabled</Badge></div><div className="settings-option"><div><b>Gemini AI requests</b><small>Resume or interview content is sent only when you trigger an AI action.</small></div><Badge tone="blue">On demand</Badge></div><Button variant="secondary" onClick={exportData}><Download size={15}/> Export my data (JSON)</Button></Panel><Panel className="settings-card"><div className="settings-card-heading"><div className="settings-icon"><UserCog size={18}/></div><div><h3>Demonstration role</h3><p>Switch the local demo role to preview administrator features.</p></div></div><div className="settings-option"><div><b>Current role</b><small>Admin access here is a frontend demonstration only, not secure authorization.</small></div><Badge tone={role === 'admin' ? 'orange' : 'neutral'}>{role === 'admin' ? 'Demo admin' : 'Student'}</Badge></div><div className="role-switch"><Button variant={role === 'student' ? 'primary' : 'secondary'} onClick={() => updateRole('student')}>Student view</Button><Button variant={role === 'admin' ? 'primary' : 'secondary'} onClick={() => { updateRole('admin'); notify('Demo admin panel enabled.'); }}>Enable demo admin</Button>{role === 'admin' && <Button variant="ghost" onClick={() => navigate('/admin')}>Open admin panel</Button>}</div></Panel></div><aside className="settings-aside"><Panel className="settings-danger"><div className="settings-card-heading"><div className="settings-icon danger"><RefreshCcw size={18}/></div><div><h3>Reset demo data</h3><p>Remove locally stored activity and restore starter data.</p></div></div><Button variant="danger" className="full-width" onClick={resetData} disabled={resetting}><RefreshCcw size={15}/>{resetting ? 'Resetting…' : 'Reset all demo data'}</Button></Panel><Panel className="settings-card"><h3>About this build</h3><div className="about-row"><span>Version</span><strong>3.0.0</strong></div><div className="about-row"><span>Appearance</span><strong>Light only</strong></div><div className="about-row"><span>Data storage</span><strong>Browser-local</strong></div><div className="about-row"><span>AI provider</span><strong>Gemini API</strong></div></Panel></aside></div>
  </>;
}
