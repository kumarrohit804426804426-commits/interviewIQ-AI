import { motion } from 'framer-motion';
import { AlertCircle, CheckCircle2, Info, Sparkles } from 'lucide-react';

export function PageHeader({ eyebrow, title, description, action, icon: Icon }) {
  return <div className="page-heading">
    <div>
      {eyebrow && <div className="eyebrow">{eyebrow}</div>}
      <div className="flex items-center gap-3">
        {Icon && <div className="heading-icon"><Icon size={20} /></div>}
        <h1>{title}</h1>
      </div>
      {description && <p>{description}</p>}
    </div>
    {action && <div className="heading-action">{action}</div>}
  </div>;
}

export function Panel({ children, className = '', padding = true }) {
  return <section className={`panel ${padding ? 'panel-pad' : ''} ${className}`}>{children}</section>;
}

export function SectionTitle({ title, description, action }) {
  return <div className="section-title"><div><h2>{title}</h2>{description && <p>{description}</p>}</div>{action}</div>;
}

export function StatCard({ label, value, change, icon: Icon, tone = 'blue', footnote }) {
  return <Panel className="stat-card">
    <div className="stat-top"><span>{label}</span><span className={`stat-icon ${tone}`}><Icon size={18} /></span></div>
    <div className="stat-value">{value}</div>
    <div className="stat-bottom">{change && <span className="stat-change">{change}</span>}{footnote && <span>{footnote}</span>}</div>
  </Panel>;
}

export function EmptyState({ icon: Icon = Sparkles, title, description, action }) {
  return <div className="empty-state"><div className="empty-icon"><Icon size={22} /></div><h3>{title}</h3><p>{description}</p>{action}</div>;
}

export function ProgressBar({ value = 0, color = 'blue' }) {
  return <div className="progress-track"><div className={`progress-fill ${color}`} style={{ width: `${Math.max(0, Math.min(100, value))}%` }} /></div>;
}

export function Badge({ children, tone = 'neutral' }) { return <span className={`badge ${tone}`}>{children}</span>; }

export function Toast({ toast }) {
  if (!toast) return null;
  const Icon = toast.type === 'error' ? AlertCircle : toast.type === 'info' ? Info : CheckCircle2;
  return <motion.div className={`toast ${toast.type}`} initial={{ opacity: 0, y: 12, scale: .98 }} animate={{ opacity: 1, y: 0, scale: 1 }} exit={{ opacity: 0, y: 8 }}><Icon size={18} /><span>{toast.message}</span></motion.div>;
}

export function Loading({ label = 'Working on it…' }) { return <div className="loading-state"><span className="spinner" />{label}</div>; }

export function Field({ label, hint, children }) { return <label className="field"><span className="field-label">{label}</span>{children}{hint && <small>{hint}</small>}</label>; }

export function Button({ children, variant = 'primary', size = 'md', className = '', ...props }) { return <button className={`btn ${variant} ${size} ${className}`} {...props}>{children}</button>; }
