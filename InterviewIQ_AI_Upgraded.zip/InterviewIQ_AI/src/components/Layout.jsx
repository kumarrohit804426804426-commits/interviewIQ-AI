import { useState } from 'react';
import { NavLink, Outlet, useLocation } from 'react-router-dom';
import { AnimatePresence, motion } from 'framer-motion';
import {
  Activity, BookOpen, Bookmark, BrainCircuit, ChevronLeft, ChevronRight, Code2, Crown, FileText,
  GraduationCap, History, Home, Menu, MessageSquareText, Settings, ShieldCheck, Sparkles, UserRound, X,
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { Toast } from './UI';

const groups = [
  { label: 'OVERVIEW', items: [{ label: 'Dashboard', to: '/', icon: Home }] },
  { label: 'PREPARATION', items: [
    { label: 'AI Mock Interview', to: '/interview', icon: MessageSquareText },
    { label: 'GATE Preparation', to: '/gate', icon: GraduationCap },
    { label: 'Programming Learning', to: '/learning', icon: BookOpen },
    { label: 'Coding Practice', to: '/coding', icon: Code2 },
    { label: 'Aptitude & Reasoning', to: '/aptitude', icon: BrainCircuit },
  ] },
  { label: 'CAREER TOOLS', items: [
    { label: 'Resume Analyzer', to: '/resume', icon: FileText },
    { label: 'Performance Tracker', to: '/performance', icon: Activity },
  ] },
  { label: 'PERSONAL', items: [
    { label: 'Saved Questions', to: '/saved', icon: Bookmark },
    { label: 'Interview History', to: '/history', icon: History },
    { label: 'My Profile', to: '/profile', icon: UserRound },
  ] },
  { label: 'ACCOUNT', items: [
    { label: 'PRO Subscription', to: '/pro', icon: Crown },
    { label: 'Settings', to: '/settings', icon: Settings },
  ] },
];

export default function Layout() {
  const [collapsed, setCollapsed] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);
  const { profile, subscription, role, toast } = useApp();
  const location = useLocation();
  const current = groups.flatMap(group => group.items).find(item => item.to === location.pathname);
  const navWidth = collapsed ? 'sidebar collapsed' : 'sidebar';

  const SidebarContent = () => <>
    <div className="brand-row"><div className="brand-mark"><Sparkles size={19} /></div>{!collapsed && <div className="brand-name">InterviewIQ <span>AI</span><small>CAREER WORKSPACE</small></div>}</div>
    <div className="nav-scroll">
      {groups.map(group => <div className="nav-group" key={group.label}><div className="nav-label">{!collapsed && group.label}</div>{group.items.map(item => {
        const Icon = item.icon;
        return <NavLink key={item.to} to={item.to} end={item.to === '/'} title={collapsed ? item.label : undefined} onClick={() => setMobileOpen(false)} className={({ isActive }) => `nav-link ${isActive ? 'active' : ''}`}><Icon size={18} strokeWidth={1.8} />{!collapsed && <span>{item.label}</span>}</NavLink>;
      })}</div>)}
      {role === 'admin' && <div className="nav-group"><div className="nav-label">ADMIN</div><NavLink to="/admin" title={collapsed ? 'Admin Panel' : undefined} onClick={() => setMobileOpen(false)} className={({ isActive }) => `nav-link ${isActive ? 'active' : ''}`}><ShieldCheck size={18} />{!collapsed && <span>Admin Panel</span>}</NavLink></div>}
    </div>
    {!collapsed && <div className="sidebar-bottom"><div className="pro-mini"><div className="pro-mini-icon"><Crown size={17} /></div><div><strong>{subscription.plan === 'PRO' ? 'PRO is active' : 'Unlock InterviewIQ PRO'}</strong><small>{subscription.plan === 'PRO' ? 'Your workspace is upgraded' : 'More practice. Deeper insights.'}</small></div><NavLink to="/pro" aria-label="View PRO"><ChevronRight size={16} /></NavLink></div><div className="sidebar-user"><div className="avatar">{profile.avatar ? <img src={profile.avatar} alt="Profile"/> : (profile.name || 'L').split(' ').map(x => x[0]).slice(0, 2).join('').toUpperCase()}</div><div className="sidebar-user-info"><strong>{profile.name || 'Learner'}</strong><small>{role === 'admin' ? 'Demo administrator' : 'Student account'}</small></div><NavLink to="/settings" title="Settings"><Settings size={16} /></NavLink></div></div>}
    <button className="collapse-btn" onClick={() => setCollapsed(!collapsed)} aria-label={collapsed ? 'Expand sidebar' : 'Collapse sidebar'}>{collapsed ? <ChevronRight size={16} /> : <ChevronLeft size={16} />}</button>
  </>;

  return <div className="app-shell">
    <aside className={navWidth}><SidebarContent /></aside>
    <AnimatePresence>{mobileOpen && <><motion.div className="mobile-scrim" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} onClick={() => setMobileOpen(false)} /><motion.aside className="mobile-sidebar" initial={{ x: -300 }} animate={{ x: 0 }} exit={{ x: -300 }}><button className="mobile-close" onClick={() => setMobileOpen(false)}><X size={20} /></button><SidebarContent /></motion.aside></>}</AnimatePresence>
    <main className={`main-area ${collapsed ? 'expanded' : ''}`}>
      <header className="topbar"><div className="topbar-left"><button className="mobile-menu" onClick={() => { setCollapsed(false); setMobileOpen(true); }}><Menu size={20} /></button><div className="breadcrumbs"><span>Workspace</span><ChevronRight size={14} /><strong>{current?.label || 'InterviewIQ AI'}</strong></div></div><div className="topbar-right"><div className="topbar-status"><span className="status-dot" /> All progress saved locally</div><div className="topbar-avatar">{profile.avatar ? <img src={profile.avatar} alt="Profile"/> : (profile.name || 'L')[0].toUpperCase()}</div></div></header>
      <div className="content-area"><Outlet /></div>
      <footer className="app-footer"><span>InterviewIQ AI · Personal career workspace</span><span>Your learning data stays in this browser</span></footer>
    </main>
    <Toast toast={toast} />
  </div>;
}
