const DB_NAME = 'interviewiq-local';
const DB_VERSION = 1;
const STORES = ['sessions', 'saved', 'resumes', 'progress', 'activity', 'submissions', 'quizzes', 'adminContent'];
let dbPromise;

function openDatabase() {
  if (dbPromise) return dbPromise;
  dbPromise = new Promise((resolve, reject) => {
    if (!('indexedDB' in window)) return reject(new Error('IndexedDB is unavailable in this browser.'));
    const request = indexedDB.open(DB_NAME, DB_VERSION);
    request.onupgradeneeded = () => {
      const db = request.result;
      STORES.forEach(store => {
        if (!db.objectStoreNames.contains(store)) db.createObjectStore(store, { keyPath: 'id' });
      });
    };
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error || new Error('Unable to open local database.'));
  });
  return dbPromise;
}

function fallbackTransaction(store, callback) {
  const key = `iq:fallback:${store}`;
  let rows = [];
  try { rows = JSON.parse(localStorage.getItem(key) || '[]'); if (!Array.isArray(rows)) rows = []; } catch { rows = []; }
  const persist = () => localStorage.setItem(key, JSON.stringify(rows));
  const fallbackStore = {
    put(item) { rows = rows.filter(row => row.id !== item.id); rows.push(item); persist(); return { result: item.id }; },
    get(id) { return { result: rows.find(row => row.id === id) }; },
    getAll() { return { result: rows }; },
    delete(id) { rows = rows.filter(row => row.id !== id); persist(); return { result: undefined }; },
    clear() { rows = []; persist(); return { result: undefined }; },
  };
  const result = callback(fallbackStore);
  return result && 'result' in result ? result.result : result;
}

async function transact(store, mode, callback) {
  let db;
  try { db = await openDatabase(); }
  catch { return fallbackTransaction(store, callback); }
  return new Promise((resolve, reject) => {
    const tx = db.transaction(store, mode);
    const objectStore = tx.objectStore(store);
    let result;
    try { result = callback(objectStore); } catch (error) { reject(error); return; }
    tx.oncomplete = () => resolve(result && 'result' in result ? result.result : result);
    tx.onerror = () => reject(tx.error || new Error('Local database transaction failed.'));
    tx.onabort = () => reject(tx.error || new Error('Local database transaction was cancelled.'));
  });
}

export const storageService = {
  getSetting(key, fallback = null) {
    try { const value = localStorage.getItem(`iq:${key}`); return value ? JSON.parse(value) : fallback; }
    catch { return fallback; }
  },
  setSetting(key, value) {
    try { localStorage.setItem(`iq:${key}`, JSON.stringify(value)); return true; } catch { return false; }
  },
  removeSetting(key) { localStorage.removeItem(`iq:${key}`); },
  async put(store, record) {
    if (!STORES.includes(store)) throw new Error('Unknown local data store.');
    const item = { ...record, id: record.id || crypto.randomUUID(), updatedAt: new Date().toISOString() };
    await transact(store, 'readwrite', os => os.put(item));
    return item;
  },
  async get(store, id) {
    return transact(store, 'readonly', os => os.get(id));
  },
  async getAll(store) {
    const rows = await transact(store, 'readonly', os => os.getAll());
    return (rows || []).sort((a, b) => new Date(b.createdAt || b.updatedAt || 0) - new Date(a.createdAt || a.updatedAt || 0));
  },
  async remove(store, id) { return transact(store, 'readwrite', os => os.delete(id)); },
  async clear(store) { return transact(store, 'readwrite', os => os.clear()); },
  async exportAll() {
    const payload = { exportedAt: new Date().toISOString(), profile: this.getSetting('profile', {}), settings: this.getSetting('preferences', {}), data: {} };
    for (const store of STORES) payload.data[store] = await this.getAll(store);
    return payload;
  },
  async resetDemoData() {
    for (const store of STORES) await this.clear(store);
    ['profile', 'preferences', 'subscription', 'demoRole', 'onboarded'].forEach(key => this.removeSetting(key));
  },
  async seed() {
    const now = Date.now();
    const daysAgo = (days) => new Date(now - days * 86400000).toISOString();
    if (!(await this.getAll('activity')).length) {
      const demo = [
        { type: 'lesson', label: 'Completed JavaScript fundamentals', points: 1, createdAt: daysAgo(5) },
        { type: 'quiz', label: 'Aptitude practice', score: 83, points: 1, createdAt: daysAgo(4) },
        { type: 'coding', label: 'Practised Two Sum', points: 1, createdAt: daysAgo(3) },
        { type: 'interview', label: 'Completed a mock interview', score: 78, points: 1, createdAt: daysAgo(2) },
        { type: 'lesson', label: 'Studied React fundamentals', points: 1, createdAt: daysAgo(1) },
      ];
      for (const item of demo) await this.put('activity', item);
    }
    if (!(await this.getAll('sessions')).length) {
      await this.put('sessions', {
        id: 'demo-interview-session', type: 'Technical', role: 'Software Developer', difficulty: 'Intermediate', score: 78, createdAt: daysAgo(2),
        questions: [{ id: 'demo-q1', question: 'Explain a project you have worked on and the problem it solves.', answer: 'I built a learning dashboard using React and local browser storage. I focused on reusable components, clear navigation, and keeping progress available after refresh.', evaluation: { score: 78, strengths: ['Relevant project context', 'Clear explanation'], weaknesses: ['Add measurable outcomes'], suggestions: ['Use a concise STAR structure'], overallFeedback: 'A solid example. Add impact and a specific technical trade-off.' } }],
        report: { overallScore: 78, summary: 'A promising foundation with clear project context. Add measurable outcomes and explain technical decisions in more depth.', readiness: 'Developing', strengths: ['Uses a concrete project example', 'Explains the goal clearly'], focusAreas: ['Quantify project impact', 'Describe technical trade-offs'], actionPlan: ['Prepare two project stories using the STAR method', 'Explain one technical decision and its trade-offs'] },
      });
    }
    if (!(await this.getAll('quizzes')).length) {
      await this.put('quizzes', { id: 'demo-aptitude-quiz', type: 'Aptitude & Reasoning', subject: 'Mixed practice', score: 5, total: 6, percentage: 83, createdAt: daysAgo(4), answers: [] });
    }
    if (!(await this.getAll('progress')).length) {
      await this.put('progress', { id: 'JavaScript:Language Foundations', language: 'JavaScript', title: 'Language Foundations', category: 'Programming lesson', completed: true, createdAt: daysAgo(1) });
    }
    if (!(await this.getAll('saved')).length) {
      await this.put('saved', { id: 'demo-saved-question', type: 'Interview question', question: 'Describe a challenging bug you solved and how you approached it.', category: 'Recommended practice', createdAt: daysAgo(1) });
    }
    if (!this.getSetting('profile')) this.setSetting('profile', { name: 'Krishiv Sharma', email: '', education: 'B.Tech · Computer Science', skills: ['React', 'JavaScript', 'Python', 'Machine Learning'], interests: ['Full-stack development', 'AI / ML'], goal: 'Build strong problem-solving and interview skills', avatar: '' });
    if (!this.getSetting('preferences')) this.setSetting('preferences', { notifications: true, weeklySummary: true });
    if (!this.getSetting('subscription')) this.setSetting('subscription', { plan: 'Free', status: 'active' });
    if (!this.getSetting('demoRole')) this.setSetting('demoRole', 'student');
  },
};
