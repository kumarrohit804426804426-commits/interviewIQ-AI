export const gateSubjects = [
  { id: 'programming', name: 'Programming & Data Structures', code: 'PDS', topics: ['C Programming', 'Arrays & Linked Lists', 'Stacks & Queues', 'Trees & Graphs', 'Searching & Sorting'] },
  { id: 'algorithms', name: 'Algorithms', code: 'Algo', topics: ['Asymptotic Analysis', 'Greedy Algorithms', 'Dynamic Programming', 'Graph Algorithms'] },
  { id: 'dbms', name: 'Database Management Systems', code: 'DBMS', topics: ['ER Model', 'Relational Algebra', 'SQL & Normalization', 'Transactions'] },
  { id: 'os', name: 'Operating Systems', code: 'OS', topics: ['Processes & Threads', 'CPU Scheduling', 'Deadlocks', 'Memory Management'] },
  { id: 'networks', name: 'Computer Networks', code: 'CN', topics: ['OSI & TCP/IP', 'Application Layer', 'Transport Layer', 'Network Layer'] },
  { id: 'maths', name: 'Engineering Mathematics', code: 'Maths', topics: ['Linear Algebra', 'Calculus', 'Probability', 'Discrete Mathematics'] },
];

export const gateQuestions = [
  { id: 'g1', subject: 'programming', topic: 'Arrays & Linked Lists', question: 'What is the worst-case time complexity of accessing the i-th element of an array by index?', options: ['O(1)', 'O(log n)', 'O(n)', 'O(n log n)'], answer: 0, explanation: 'Array elements are stored contiguously, so an indexed access is constant time.' },
  { id: 'g2', subject: 'programming', topic: 'Stacks & Queues', question: 'Which data structure is most directly used to implement a function call stack?', options: ['Queue', 'Stack', 'Heap', 'Graph'], answer: 1, explanation: 'Function calls use last-in, first-out order, which is the defining behavior of a stack.' },
  { id: 'g3', subject: 'algorithms', topic: 'Asymptotic Analysis', question: 'What is the time complexity of binary search on a sorted array?', options: ['O(n)', 'O(log n)', 'O(n log n)', 'O(1)'], answer: 1, explanation: 'Binary search halves the remaining search interval at each step.' },
  { id: 'g4', subject: 'dbms', topic: 'SQL & Normalization', question: 'Which normal form removes partial dependency on a candidate key?', options: ['1NF', '2NF', '3NF', 'BCNF'], answer: 1, explanation: 'Second Normal Form requires 1NF and no non-prime attribute to depend on a proper subset of a candidate key.' },
  { id: 'g5', subject: 'os', topic: 'Processes & Threads', question: 'Which of the following is shared by threads of the same process?', options: ['Stack', 'Program counter', 'Register set', 'Address space'], answer: 3, explanation: 'Threads share the process address space and resources, but each thread has its own stack and register context.' },
  { id: 'g6', subject: 'networks', topic: 'Transport Layer', question: 'Which transport protocol provides ordered, reliable byte-stream delivery?', options: ['UDP', 'IP', 'TCP', 'ARP'], answer: 2, explanation: 'TCP provides reliable, ordered delivery using acknowledgements and retransmission.' },
  { id: 'g7', subject: 'maths', topic: 'Probability', question: 'For two independent events A and B, P(A ∩ B) equals:', options: ['P(A) + P(B)', 'P(A)P(B)', 'P(A) / P(B)', 'P(A) − P(B)'], answer: 1, explanation: 'Independence means the probability of both events is the product of their probabilities.' },
];

export const aptitudeQuestions = [
  { id: 'a1', category: 'Quantitative Aptitude', question: 'A product marked at ₹800 is sold at a 10% discount. What is the selling price?', options: ['₹700', '₹720', '₹740', '₹760'], answer: 1, explanation: '10% of ₹800 is ₹80. Selling price = ₹800 − ₹80 = ₹720.' },
  { id: 'a2', category: 'Quantitative Aptitude', question: 'A train covers 150 km in 2.5 hours. What is its average speed?', options: ['50 km/h', '55 km/h', '60 km/h', '65 km/h'], answer: 2, explanation: 'Speed = distance ÷ time = 150 ÷ 2.5 = 60 km/h.' },
  { id: 'a3', category: 'Logical Reasoning', question: 'Find the next number: 2, 6, 12, 20, 30, __', options: ['36', '40', '42', '44'], answer: 2, explanation: 'The differences are 4, 6, 8, 10, so the next difference is 12. The answer is 42.' },
  { id: 'a4', category: 'Logical Reasoning', question: 'If all Bloops are Razzies and all Razzies are Lazzies, which statement must be true?', options: ['All Lazzies are Bloops', 'All Bloops are Lazzies', 'No Bloops are Lazzies', 'Some Razzies are not Bloops'], answer: 1, explanation: 'The relationship is transitive: Bloops are a subset of Razzies, and Razzies are a subset of Lazzies.' },
  { id: 'a5', category: 'Verbal Ability', question: 'Choose the closest meaning of “concise”.', options: ['Confusing', 'Brief and clear', 'Detailed', 'Uncertain'], answer: 1, explanation: 'Concise means expressing something clearly in few words.' },
  { id: 'a6', category: 'Verbal Ability', question: 'Choose the grammatically correct sentence.', options: ['She have completed the task.', 'She has completed the task.', 'She having completed the task.', 'She complete the task yesterday.'], answer: 1, explanation: '“She” takes “has” in the present perfect tense.' },
];

export const programmingPaths = [
  { language: 'C', tone: 'C fundamentals', lessons: [
    ['Syntax & Data Types', 'Understand the structure of a C program, variables, constants and primitive data types.', 'int age = 19;\nfloat score = 92.5f;\nprintf("%d %.1f", age, score);'],
    ['Conditions & Loops', 'Use if/else, switch, for, while and do-while to control program flow.', 'for (int i = 1; i <= 5; i++) {\n  printf("%d\\n", i);\n}'],
    ['Functions & Pointers', 'Break programs into reusable functions and understand addresses and pointer operations.', 'int value = 10;\nint *ptr = &value;\nprintf("%d", *ptr);'],
    ['Arrays & Strings', 'Store sequences of values and work with null-terminated character arrays.', 'int nums[] = {2, 4, 6};\nprintf("%d", nums[1]);'],
  ]},
  { language: 'C++', tone: 'Object-oriented C++', lessons: [
    ['C++ Foundations', 'Explore streams, namespaces, references and the standard library.', '#include <iostream>\nusing namespace std;\nint main(){ cout << "Hello"; }'],
    ['Classes & Objects', 'Model real-world entities with fields, methods, constructors and access modifiers.', 'class Student {\npublic:\n  string name;\n  void introduce(){ cout << name; }\n};'],
    ['Inheritance & Polymorphism', 'Reuse behavior through inheritance and customize virtual methods.', 'class Shape { public: virtual double area() = 0; };'],
    ['STL & Templates', 'Use vector, map, set, iterators and generic functions.', 'vector<int> values = {3, 1, 2};\nsort(values.begin(), values.end());'],
  ]},
  { language: 'Java', tone: 'Java development', lessons: [
    ['Java Basics', 'Learn classes, main method, variables, operators and console input.', 'public class Main {\n  public static void main(String[] args) {\n    System.out.println("Hello");\n  }\n}'],
    ['OOP & Constructors', 'Use encapsulation, constructors, overloading and inheritance.', 'class Person {\n  String name;\n  Person(String name) { this.name = name; }\n}'],
    ['Collections & Exceptions', 'Work with List, Map, Set and robust exception handling.', 'List<String> names = new ArrayList<>();\nnames.add("Asha");'],
    ['Threads & File I/O', 'Understand Runnable, Thread lifecycle and basic file operations.', 'Runnable job = () -> System.out.println("Running");\nnew Thread(job).start();'],
  ]},
  { language: 'Python', tone: 'Python for problem solving', lessons: [
    ['Python Essentials', 'Work with indentation, variables, built-in types and operators.', 'name = "InterviewIQ"\nscore = 95\nprint(f"{name}: {score}")'],
    ['Control Flow & Functions', 'Write conditional logic, loops and reusable functions.', 'def is_even(number):\n    return number % 2 == 0'],
    ['Data Structures', 'Use lists, tuples, dictionaries, sets and comprehensions.', 'squares = [n * n for n in range(1, 6)]'],
    ['OOP & Modules', 'Create classes, use inheritance and organize code into modules.', 'class Candidate:\n    def __init__(self, name):\n        self.name = name'],
  ]},
  { language: 'JavaScript', tone: 'Modern JavaScript', lessons: [
    ['Language Foundations', 'Understand let/const, types, equality, arrays and objects.', 'const candidate = { name: "Asha", ready: true };'],
    ['Functions & DOM', 'Use arrow functions, callbacks, events and DOM interaction.', 'const greet = (name) => `Hello, ${name}`;'],
    ['Async JavaScript', 'Work with promises, async/await, fetch and error handling.', 'async function load() {\n  const response = await fetch("/api/health");\n  return response.json();\n}'],
    ['React Fundamentals', 'Build reusable components using props, state and effects.', 'function Counter() {\n  const [count, setCount] = useState(0);\n  return <button onClick={() => setCount(count + 1)}>{count}</button>;\n}'],
  ]},
];

export const codingProblems = [
  { id: 'two-sum', title: 'Two Sum', difficulty: 'Easy', topics: ['Arrays', 'Hash Map'], description: 'Given an array of integers and a target, return the indices of the two numbers that add up to the target. Assume exactly one solution exists.', example: 'Input: nums = [2,7,11,15], target = 9\nOutput: [0,1]', starter: 'function twoSum(nums, target) {\n  // Write your solution here\n}', hint: 'A hash map can store numbers you have already seen.' },
  { id: 'valid-palindrome', title: 'Valid Palindrome', difficulty: 'Easy', topics: ['Strings', 'Two Pointers'], description: 'Return true if a string is a palindrome after converting to lowercase and removing non-alphanumeric characters.', example: 'Input: "A man, a plan, a canal: Panama"\nOutput: true', starter: 'function isPalindrome(s) {\n  // Write your solution here\n}', hint: 'Normalize the string, then compare characters from both ends.' },
  { id: 'binary-search', title: 'Binary Search', difficulty: 'Medium', topics: ['Arrays', 'Binary Search'], description: 'Given a sorted array of distinct integers and a target, return its index. Return -1 when the target is absent.', example: 'Input: nums = [-1,0,3,5,9,12], target = 9\nOutput: 4', starter: 'function search(nums, target) {\n  // Write your solution here\n}', hint: 'Maintain low and high pointers and discard half the interval each iteration.' },
  { id: 'max-subarray', title: 'Maximum Subarray', difficulty: 'Medium', topics: ['Arrays', 'Dynamic Programming'], description: 'Find the contiguous subarray with the largest sum and return that sum.', example: 'Input: nums = [-2,1,-3,4,-1,2,1,-5,4]\nOutput: 6', starter: 'function maxSubArray(nums) {\n  // Write your solution here\n}', hint: 'Kadane’s algorithm tracks the best sum ending at the current position.' },
  { id: 'longest-substring', title: 'Longest Substring Without Repeating Characters', difficulty: 'Hard', topics: ['Strings', 'Sliding Window'], description: 'Return the length of the longest substring without repeating characters.', example: 'Input: "abcabcbb"\nOutput: 3', starter: 'function lengthOfLongestSubstring(s) {\n  // Write your solution here\n}', hint: 'Use a sliding window and track the most recent position of each character.' },
];

export const recommendedQuestions = [
  'Explain the difference between an array and a linked list.',
  'What happens when you type a URL into a browser?',
  'Describe a project where you had to debug a difficult issue.',
  'What is the difference between processes and threads?',
];
