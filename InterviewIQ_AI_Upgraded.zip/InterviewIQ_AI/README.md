# InterviewIQ AI — v3.0

A browser-first AI interview and career preparation workspace. The supplied v2 archive contained only an Express backend and no frontend source, so this upgrade creates a React + Vite application and replaces the JSON-file account/practice database with browser-local persistence.

## Highlights

- **Premium light UI:** responsive sidebar, Apple-inspired spacing and typography, clean cards, subtle blue accents, and reusable components.
- **Dashboard:** weekly activity, practice statistics, recent activity, preparation pulse, recommended questions, and optional Gemini learning recommendations.
- **AI Mock Interview:** generate role-specific technical, HR, behavioral or company-specific questions; evaluate answers; create a full session report; store sessions in IndexedDB.
- **GATE Preparation:** subject and topic navigation, local MCQ question bank, optional year tags for previous-year organization, answer explanations, scoring, and saved questions. Unverified starter items are clearly treated as practice rather than official PYQs.
- **Programming Learning:** structured C, C++, Java, Python and JavaScript learning paths with code examples and local completion tracking. Demo admins can publish additional browser-local lessons.
- **Coding Practice:** difficulty/topic filters, problem statements, starter code editor, and local submission history. It does **not** execute code.
- **Aptitude & Reasoning:** quantitative, logical and verbal MCQs, 10-minute timer, automatic score, explanations, and saved quiz history.
- **Resume Analyzer:** PDF/TXT text extraction, Gemini analysis, strengths, missing keywords, skill recommendations, and an AI-generated estimate (not a verified ATS score).
- **Performance Tracker:** activity trends, quiz averages, interview results, coding attempts and learning progress.
- **Personal workspace:** saved interview/GATE/coding questions, interview history/report review, editable profile, simulated PRO subscription, settings, JSON data export, and reset.
- **Demo Admin Panel:** local question/year-tag management, custom lesson publishing, quiz/progress record management and sample metrics. Admin role checks are frontend-only and are not secure production authorization.

## Tech stack

- React 18 + Vite
- JavaScript + Tailwind CSS (with a small custom design system)
- React Router, Framer Motion, Lucide React, Recharts
- IndexedDB for larger local records; LocalStorage for preferences/profile/subscription/demo role
- Node.js + Express as a small Gemini proxy only
- Google Gemini API (one server-side key, centralized `src/services/geminiService.js`)

There is no MongoDB, Firebase, Supabase, external database, or server-side user account system in this version.

## Run locally

1. Install Node.js 18 or newer.
2. In this folder, install packages:
   ```bash
   npm install
   ```
3. Copy `.env.example` to `.env` and add your Gemini API key:
   ```env
   GEMINI_API_KEY=your_actual_key_here
   GEMINI_MODEL=gemini-3.8-flash
   PORT=3000
   ```
   Create a key in [Google AI Studio](https://aistudio.google.com/app/apikey). Keep the key in `.env`; do not paste it into React code or commit `.env`.
4. Start the API proxy in Terminal 1:
   ```bash
   npm run dev:server
   ```
5. Start the Vite app in Terminal 2:
   ```bash
   npm run dev
   ```
6. Open the Vite URL, normally `http://localhost:5173`.

The Gemini-powered screens show a clear configuration error when the API key is missing. All local question banks, lessons, quiz scoring, saved items and browser analytics remain usable without Gemini.

## Production / local demo build

```bash
npm install
npm run build
npm start
```

Then open `http://localhost:3000`. The Express server serves the built `dist` folder and the `/api/gemini` proxy.

## Data and privacy

- LocalStorage stores the profile, preferences, subscription demo state and demonstration role.
- IndexedDB stores interview sessions, saved items, resume text/analysis, progress, activity, coding submissions, quizzes and additional demo content.
- Browser data survives refreshes but does not sync across browsers or devices. Clearing browser site data removes it.
- Use Settings → Export my data to download a JSON backup, or Reset all demo data to clear the app's local records.
- Resume and interview text is only sent to Gemini when the user explicitly starts the related AI action. The server-side proxy keeps the API key out of frontend JavaScript.

## Important limitations

- This is a local-first demonstration, not a production multi-user SaaS deployment. Login/registration and server-side account storage from v2 were removed as requested when migrating to browser storage; consequently, account logout is not applicable in this build.
- Gemini features require a valid API key, model access and internet connectivity. Model access and quotas are controlled by Google.
- Coding practice does not compile or execute submitted code; it stores local drafts/submissions only.
- Resume compatibility is an AI-generated estimate, not an official ATS score or hiring prediction.
- PRO upgrade/checkout is simulated only. No payment method is collected and no payment is processed.
- Admin mode is a frontend demonstration toggle only; it must not be treated as secure authorization.
- GATE and aptitude content is a starter local question bank, not a complete or officially verified previous-year question archive.

## Project structure

```text
InterviewIQ_AI/
├── server.js
├── index.html
├── vite.config.js
├── tailwind.config.js
├── postcss.config.js
├── .env.example
└── src/
    ├── App.jsx
    ├── main.jsx
    ├── index.css
    ├── components/
    ├── context/
    ├── data/
    ├── pages/
    └── services/
        ├── geminiService.js
        └── storageService.js
```

## Before production

Add real identity and authorization, a suitable synchronized database if multi-device accounts are required, automated tests, server-side policy/usage controls, deployment secrets, stronger request validation, privacy/terms pages, monitoring, and a safe code execution sandbox only if code execution becomes a requirement.
