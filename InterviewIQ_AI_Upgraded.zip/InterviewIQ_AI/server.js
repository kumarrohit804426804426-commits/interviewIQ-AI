import 'dotenv/config';
import express from 'express';
import helmet from 'helmet';
import rateLimit from 'express-rate-limit';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const app = express();
const PORT = Number(process.env.PORT || 3000);
const MODEL = process.env.GEMINI_MODEL || 'gemini-3.8-flash';
const __dirname = path.dirname(fileURLToPath(import.meta.url));

app.disable('x-powered-by');
app.use(helmet({ contentSecurityPolicy: false, crossOriginEmbedderPolicy: false }));
app.use(express.json({ limit: '8mb' }));
app.use('/api/', rateLimit({ windowMs: 60_000, limit: 30, standardHeaders: 'draft-7', legacyHeaders: false }));

app.get('/api/health', (_req, res) => res.json({ status: 'ok', service: 'InterviewIQ AI', aiConfigured: Boolean(process.env.GEMINI_API_KEY), model: MODEL }));

app.post('/api/gemini', async (req, res) => {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) return res.status(503).json({ error: 'Gemini is not configured. Add GEMINI_API_KEY to your .env file and restart the server.' });
  const prompt = typeof req.body?.prompt === 'string' ? req.body.prompt.trim() : '';
  if (!prompt || prompt.length > 180_000) return res.status(400).json({ error: 'A valid prompt is required (maximum 180,000 characters).' });
  const generationConfig = req.body?.generationConfig && typeof req.body.generationConfig === 'object' ? req.body.generationConfig : {};
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 60_000);
  try {
    const response = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(MODEL)}:generateContent`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'x-goog-api-key': apiKey },
      body: JSON.stringify({ contents: [{ role: 'user', parts: [{ text: prompt }] }], generationConfig: { temperature: 0.35, maxOutputTokens: 4096, ...generationConfig } }),
      signal: controller.signal,
    });
    const payload = await response.json().catch(() => ({}));
    if (!response.ok) {
      const message = payload?.error?.message || `Gemini request failed (${response.status}).`;
      return res.status(response.status >= 500 ? 502 : response.status).json({ error: message });
    }
    const text = payload?.candidates?.[0]?.content?.parts?.map(part => part.text || '').join('').trim();
    if (!text) return res.status(502).json({ error: 'Gemini returned an empty response. Please retry.' });
    res.json({ text, model: MODEL, usageMetadata: payload.usageMetadata || null });
  } catch (error) {
    const aborted = error.name === 'AbortError';
    res.status(aborted ? 504 : 502).json({ error: aborted ? 'Gemini took too long to respond. Please retry.' : 'Unable to reach Gemini. Check your connection and try again.' });
  } finally {
    clearTimeout(timeout);
  }
});

const distPath = path.join(__dirname, 'dist');
app.use(express.static(distPath, { maxAge: process.env.NODE_ENV === 'production' ? '1h' : 0 }));
app.get('*', (req, res, next) => {
  if (req.path.startsWith('/api/')) return next();
  res.sendFile(path.join(distPath, 'index.html'), error => { if (error) next(); });
});
app.use((err, _req, res, _next) => { console.error(err); res.status(500).json({ error: 'Unexpected server error.' }); });
app.listen(PORT, () => console.log(`InterviewIQ AI server listening on http://localhost:${PORT}`));
